"""Focused cooperative Python guard; preserves product and test behavior."""
import json
import ntpath
import os
from pathlib import Path
import sys

FORBIDDEN = r'C:\Users\hello\AppData\Local\Uoink\index.db'
assert os.environ['IG_FORBIDDEN_LIVE'] == FORBIDDEN
assert os.environ['HF_HUB_OFFLINE'] == '1'
assert os.environ['TRANSFORMERS_OFFLINE'] == '1'
assert os.environ['HF_DATASETS_OFFLINE'] == '1'
ROOT = os.environ['IG_FOCUSED_ROOT']
LABEL = os.environ['IG_FOCUSED_LABEL']
DESTINATION = os.environ['IG_FOCUSED_GUARD_RECEIPT']
EVENTS = []

def lexical(value):
    if not isinstance(value, (str, bytes, os.PathLike)): return None
    text = os.fsdecode(value).replace('/', '\\')
    if text.startswith('\\\\?\\'): text = text[4:]
    elif text.startswith('\\??\\'): text = text[4:]
    return ntpath.normcase(ntpath.abspath(text))

LIVE_DIRECTORY = ntpath.dirname(lexical(FORBIDDEN))
EXPECTED_DATA = lexical(ntpath.join(ROOT, '_scratch', LABEL))
assert lexical(os.environ['LOCALAPPDATA']) == EXPECTED_DATA
assert lexical(os.environ['APPDATA']) == EXPECTED_DATA
assert lexical(os.environ['UOINK_INDEX_PATH']) == ntpath.join(EXPECTED_DATA, 'unused-index.db')

def reject(event, path=None):
    row = {'event': event}
    if path is not None: row['path'] = os.fsdecode(path)
    EVENTS.append(row)
    raise PermissionError('Focused verification guard denied ' + event)

def check_live(value, event):
    name = lexical(value)
    if name is not None and (name == LIVE_DIRECTORY or name.startswith(LIVE_DIRECTORY + '\\')):
        reject(event, value)

# os.path.realpath is included because Windows can query final-path metadata
# directly without calling the public os.stat wrapper. These checks operate
# on strings first and never resolve/stat the forbidden destination itself.
ORIGINALS = {name: getattr(os, name) for name in ('stat', 'lstat', 'readlink')}
ORIGINAL_REALPATH = os.path.realpath
WRAPPERS = {}
for name, original in ORIGINALS.items():
    def wrapped(path, *args, _name=name, _original=original, **kwargs):
        check_live(path, 'os.' + _name)
        return _original(path, *args, **kwargs)
    WRAPPERS[name] = wrapped
    setattr(os, name, wrapped)

def guarded_realpath(path, *args, **kwargs):
    check_live(path, 'os.path.realpath')
    return ORIGINAL_REALPATH(path, *args, **kwargs)
os.path.realpath = guarded_realpath

# Explicit reviewed Node launch exception. This block is inserted into the
# prior lexical Python guard before its audit hook, without changing tests.
import hashlib
import subprocess
import threading

NODE_PROFILE_PATH = Path(os.environ['IG_NODE_PROFILE'])
NODE_PROFILE = json.loads(NODE_PROFILE_PATH.read_text(encoding='utf-8'))
NODE_EXECUTABLE = NODE_PROFILE['node_executable']
NODE_PRELOAD = Path(os.environ['IG_NODE_PRELOAD'])
NODE_DESTINATION = Path(os.environ['IG_NODE_OUTPUT'])
NODE_DASHBOARD = Path(ROOT) / 'assets/dashboard/index.html'
NODE_DASHBOARD_SHA = os.environ['IG_NODE_DASHBOARD_SHA']
NODE_HARNESS = (NODE_PROFILE_PATH.parent / NODE_PROFILE['harness_file']).read_text(encoding='utf-8')
NODE_PENDING = threading.local()
NODE_RECORDS = []
CURRENT_CASE = None
ORIGINAL_POPEN = subprocess.Popen

def digest_file(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert hashlib.sha256(NODE_HARNESS.encode('utf-8')).hexdigest() == NODE_PROFILE['harness_sha256']
assert digest_file(NODE_EXECUTABLE) == NODE_PROFILE['node_sha256']
assert Path(NODE_EXECUTABLE).stat().st_size == NODE_PROFILE['node_bytes']
assert digest_file(NODE_PRELOAD) == os.environ['IG_NODE_PRELOAD_SHA']
assert digest_file(NODE_DASHBOARD) == NODE_DASHBOARD_SHA
assert digest_file(Path(ROOT) / 'tests/test_reliability_settings_ui.py') == NODE_PROFILE['ui_test_sha256']
assert NODE_DESTINATION.is_dir()

def save_node(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8', newline='\n')

class ExactNodePopen(ORIGINAL_POPEN):
    def __init__(self, args, *positional, **kwargs):
        expected_kwargs = {'stdin': subprocess.PIPE, 'stdout': subprocess.PIPE,
            'stderr': subprocess.PIPE, 'text': True, 'cwd': Path(ROOT)}
        if (positional or not isinstance(args, list) or args != ['node', '-e', NODE_HARNESS]
            or kwargs != expected_kwargs or CURRENT_CASE is None
            or CURRENT_CASE.split('::')[0] not in {
                'tests/test_reliability_settings_ui.py', 'tests/test_reliability_review_boundaries.py'}):
            reject('unreviewed subprocess request')
        if digest_file(NODE_DASHBOARD) != NODE_DASHBOARD_SHA:
            reject('dashboard changed before Node')
        folder = NODE_DESTINATION / ('node-%03d' % (len(NODE_RECORDS)+1))
        folder.mkdir(exist_ok=False)
        child_receipt = folder / 'guard.json'
        actual = [NODE_EXECUTABLE, '--permission',
            '--allow-fs-read=' + str(NODE_DASHBOARD),
            '--allow-fs-read=' + str(NODE_PRELOAD),
            '--allow-fs-write=' + str(child_receipt),
            '--require=' + str(NODE_PRELOAD), '-e', NODE_HARNESS]
        child_env = {key: value for key, value in os.environ.items()
            if key.upper() in {'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'HOME', 'USERPROFILE',
                'LOCALAPPDATA', 'APPDATA', 'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', 'HF_DATASETS_OFFLINE'}}
        child_env.update(IG_NODE_DASHBOARD=str(NODE_DASHBOARD),
            IG_NODE_DASHBOARD_SHA=NODE_DASHBOARD_SHA,
            IG_NODE_HARNESS_SHA=NODE_PROFILE['harness_sha256'],
            IG_NODE_RECEIPT=str(child_receipt), IG_NODE_LABEL=LABEL + '-' + folder.name)
        self._node_record = {'case_id': CURRENT_CASE, 'requested_argv': args,
            'actual_argv': actual, 'cwd': str(ROOT), 'folder': str(folder),
            'child_environment_names': sorted(child_env), 'communications': [],
            'actual_exit': None, 'spawned': False}
        NODE_RECORDS.append(self._node_record)
        save_node(folder / 'launch.json', self._node_record)
        assert getattr(NODE_PENDING, 'value', None) is None
        NODE_PENDING.value = (lexical(NODE_EXECUTABLE), subprocess.list2cmdline(actual), lexical(ROOT))
        try:
            super().__init__(actual, executable=NODE_EXECUTABLE, env=child_env, **kwargs)
            self._node_record['spawned'] = True
        except BaseException as error:
            self._node_record['launch_error'] = type(error).__name__ + ': ' + str(error)
            raise
        finally:
            NODE_PENDING.value = None
            save_node(folder / 'launch.json', self._node_record)

    def communicate(self, input=None, timeout=None):
        communication = {'stdin': input, 'timeout': timeout}
        self._node_record['communications'].append(communication)
        try:
            stdout, stderr = super().communicate(input=input, timeout=timeout)
            communication.update(stdout=stdout, stderr=stderr)
            return stdout, stderr
        except BaseException as error:
            communication['error'] = type(error).__name__ + ': ' + str(error)
            raise
        finally:
            self._node_record['actual_exit'] = self.returncode
            save_node(Path(self._node_record['folder']) / 'launch.json', self._node_record)

subprocess.Popen = ExactNodePopen

def admit_node_audit(args):
    expected = getattr(NODE_PENDING, 'value', None)
    if expected is None or len(args) != 4:
        return False
    executable, argv, cwd, env = args
    actual = (lexical(executable), argv, lexical(cwd))
    if actual != expected:
        return False
    NODE_PENDING.value = None  # one process for one reviewed request
    return True

def pytest_runtest_setup(item):
    global CURRENT_CASE
    CURRENT_CASE = item.nodeid

def pytest_runtest_teardown(item):
    global CURRENT_CASE
    CURRENT_CASE = None

def node_finish():
    unchanged = (digest_file(NODE_EXECUTABLE) == NODE_PROFILE['node_sha256']
        and digest_file(NODE_PRELOAD) == os.environ['IG_NODE_PRELOAD_SHA']
        and digest_file(NODE_DASHBOARD) == NODE_DASHBOARD_SHA
        and digest_file(Path(ROOT) / 'tests/test_reliability_settings_ui.py') == NODE_PROFILE['ui_test_sha256'])
    installed = subprocess.Popen is ExactNodePopen
    children = []
    for record in NODE_RECORDS:
        path = Path(record['folder']) / 'guard.json'
        try:
            receipt = json.loads(path.read_text(encoding='utf-8'))
            valid = (record['spawned'] and record['actual_exit'] == 0
                and receipt['actualExitCode'] == record['actual_exit'] and receipt['valid']
                and not receipt['violations'] and receipt['sourceUnchanged']
                and receipt['dashboardSha256'] == NODE_DASHBOARD_SHA
                and receipt['harnessSha256'] == NODE_PROFILE['harness_sha256'])
            children.append({'case_id': record['case_id'], 'receipt': str(path), 'valid': bool(valid)})
        except (OSError, ValueError, KeyError) as error:
            children.append({'case_id': record['case_id'], 'receipt': str(path), 'valid': False,
                'receipt_error': type(error).__name__ + ': ' + str(error)})
    return {'executable_sha256': NODE_PROFILE['node_sha256'], 'inputs_unchanged': unchanged,
        'adapter_installed_at_finish': installed, 'child_count': len(children), 'children': children,
        'valid': unchanged and installed and all(row['valid'] for row in children)}


def audit(event, args):
    if event in {'open', 'sqlite3.connect', 'os.listdir', 'os.scandir'} and args:
        check_live(args[0], event)
    if event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.utime'} and args:
        check_live(args[0], event)
    if event in {'os.rename', 'os.link', 'os.symlink'}:
        for value in args[:2]: check_live(value, event)
    if event == 'subprocess.Popen' and admit_node_audit(args):
        return
    if event.startswith('socket.') or event in {
        'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.spawn',
        'os.startfile', 'os.startfile/2', 'os.add_dll_directory',
    }:
        reject(event)
sys.addaudithook(audit)

def pytest_sessionfinish(session, exitstatus):
    installed = all(getattr(os, name) is wrapper for name, wrapper in WRAPPERS.items()) and os.path.realpath is guarded_realpath
    node = node_finish()
    receipt = {'profile': 'reliability-focused-exact-node-vm',
        'node': node,
        'pytest_exitstatus': int(exitstatus), 'violations': EVENTS,
        'lexical_wrappers_installed_at_finish': installed,
        'audit_hook_installed': True,
        'valid': installed and not EVENTS and node['valid'],
        'scope': 'Cooperative Python process guard; no model/native/OS-sandbox credit. Existing inert test mocks remain permitted.'}
    Path(DESTINATION).write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')

The focused union is ready for root source review. It has not been executed.

The five existing suites and four new Python regression files are all required
by the launcher. `ROOT-ADMISSION.TEMPLATE.json` binds their finished worker bytes,
three product files, frozen dependency/build inputs, and the execution
instruments. Root must set its review fields, exact source commit and fresh
labels in a separate admission file. Collection establishes the case count;
no count in this preparation is a test result.

The main baseline is expected to expose two product defects: resolving the
cache root before checking its original identity, and borrowing a saved model's
size for a different unknown selection. Both independent assertions remain in
`tests/test_reliability_review_boundaries.py`. The finished worker already sets
the constructor default and ordinary callers to local-only. Binding that
constructor to a validated snapshot would be separate hardening; this review
does not present it as a demonstrated new consent bypass. Root's separate
omitted-keyword baseline probe is outside this union.

The worker report describes local checks, but its raw receipts were absent from
the finished worktree. Those statements provide no acceptance credit. Root's
baseline and corrected runs must retain their own actual exits and evidence.

Only the exact UI test's `subprocess.run(["node", "-e", HARNESS], ...)` request
is admitted. The Python adapter fixes the executable, permission flags, preload,
cwd, dashboard hash and HARNESS hash. It records the requested and actual argv,
stdin, stdout, stderr, timeout and actual exit for every child. A per-thread,
single-use audit gate admits that exact launch; other subprocess requests and
socket activity remain denied. Collection cannot start Node.

The Node child receives a small environment containing Windows/runtime paths,
temporary profile paths, offline flags and exact guard bindings. It inherits no
provider keys, Node options or proxy settings. Its permission flags grant reads
only for dashboard text and the preload and writes only for one fresh receipt.
The preload's fs and vm facades preserve the existing fake UI/fetch/confirm
functions and permit only the captured dashboard blocks. Other module loads,
network globals, native binding entry points and process-control calls fail.
Node permissions and vm are cooperative controls for these reviewed sources;
they do not establish a malicious-code sandbox. Paths must remain quiescent;
hashes before/after do not give atomic protection against replacement.

Before execution, source review found that the initial preload's expected
context keys omitted the HARNESS's existing fake `fetch`. Root independently
found the same mismatch. The only correction adds `fetch` to that sorted key
list. `PREQUALIFICATION-CORRECTION.json` and its diff preserve this preparation
change. The prior draft was never launched; there is no test failure to relabel.
The earlier draft bytes are reconstructed from the exact single-key edit and
explicitly marked as such.

The earlier 31-payload seal and its reference instruments remain unchanged.
The Python files were parsed as text with `ast.parse`; neither the Python guard
nor Node preload was executed by this author. Root still needs to qualify their
startup behavior. Any guard or test failure must retain raw evidence before a
documented repair and fresh label. No model, installed GUI, download, full-tree,
dependency migration or market-readiness claim follows from this preparation.

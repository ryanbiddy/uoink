# Node profile references

Read on September 13, 2026, for the installed executable's version 24.18.0.
These are documentation reads; Node was not launched.

Permission mode restricts filesystem operations, child processes, workers,
addons, WASI and the inspector. It does not guarantee isolation from malicious
code, and existing file descriptors can bypass filesystem permission checks.
The proposed profile therefore admits only stdin plus exact reviewed source
and retains an additional module/network guard. [Versioned permissions documentation](https://nodejs.org/download/release/v24.18.0/docs/api/permissions.html)

Use `--permission`, separate exact `--allow-fs-read` arguments, a single exact
receipt `--allow-fs-write` path and `--require` for the reviewed preload. Grant
no child-process, worker, addon, WASI or inspector flags. [Versioned CLI documentation](https://nodejs.org/download/release/v24.18.0/docs/api/cli.html)

The preload checks the documented `fs.read`, `fs.write`, `child` and `worker`
permission scopes at startup. [Versioned process API](https://nodejs.org/download/release/v24.18.0/docs/api/process.html#processpermissionhasscope-reference)

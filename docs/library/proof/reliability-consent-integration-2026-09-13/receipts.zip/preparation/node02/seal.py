"""Seal prepared text only. Does not launch tests, Node, product or model code."""
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / 'reliability-focused-instrument01'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def save(name, value):
    with (OUT/name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2)+'\n')

prior_raw = (PRIOR/'SHA256.json').read_bytes()
assert sha(prior_raw) == 'a06eee5c9ecc0b550b91dba9a930d91adfcb8588cc8ab68cf0be24f6e8dc2362'
old = json.loads(prior_raw)
assert len(old['payloads']) == old['payload_count'] == 31
for row in old['payloads']:
    raw = (PRIOR/row['file']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['file']

current = (OUT/'node_guard.cjs').read_bytes()
needle = b"['authFetch', 'confirm', 'console', 'els', 'fetch', 'refreshSettings', 'showToast']"
previous = b"['authFetch', 'confirm', 'console', 'els', 'refreshSettings', 'showToast']"
assert current.count(needle) == 1
before = current.replace(needle, previous)
(OUT/'prequalification-before').mkdir(exist_ok=False)
(OUT/'prequalification-before/node_guard.cjs').write_bytes(before)
delta = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
    current.decode().splitlines(keepends=True), fromfile='initial-draft/node_guard.cjs',
    tofile='prepared/node_guard.cjs'))
(OUT/'instrument-diffs/fake-fetch-key.patch').write_text(delta, encoding='utf-8', newline='\n')
save('PREQUALIFICATION-CORRECTION.json', {'reason': 'Exact HARNESS context includes an existing fake fetch; initial expected key list omitted it.',
    'before_sha256': sha(before), 'after_sha256': sha(current),
    'before_preservation': 'Reconstructed exact preceding bytes from the single known edit; not an independently captured earlier file.',
    'changed_behavior': 'Preload admits the existing throwing fake fetch key; HARNESS and assertions unchanged.',
    'test_or_node_execution_before_or_after': False, 'source_review_only': True})
parsed = []
for path in sorted(OUT.glob('*.py')):
    ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    parsed.append(path.name)
save('FINAL-CHECKS.json', {'prior31_verified_unchanged': True,
    'python_parsed_only': parsed, 'python_guard_executed': False,
    'node_executed': False, 'tests_executed': False,
    'heavy_or_product_imports': False,
    'scope': 'Preparation only; root review and execution qualification remain required.'})
payloads = []
for path in sorted(OUT.rglob('*')):
    if path.is_file():
        raw = path.read_bytes()
        payloads.append({'file': path.relative_to(OUT).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
save('SHA256.json', {'created_utc': datetime.now(timezone.utc).isoformat(),
    'payload_count': len(payloads), 'scope': 'Unexecuted exact Node VM focused-test instrumentation preparation',
    'payloads': payloads})
print(json.dumps({'payload_count': len(payloads), 'manifest_sha256': sha((OUT/'SHA256.json').read_bytes()),
    'prior31_unchanged': True, 'node_or_tests_executed': False}))

Review `launch.py`, `reliability_focused_guard.py`, `node_guard.cjs`, their explicit
instrument diffs and all final worker files first. Use the template to write a
separate root admission under the checkout's `_scratch` directory. Set both
review booleans, the review-document path, exact commit IDs and fresh labels.
The template is deliberately not executable as approval.

The worker baseline command, from the checkout, is:

```powershell
& 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-focused-node02\run-root.ps1' -Target worker -Admission 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-root-baseline01.json'
```

That wrapper records the actual outer exit separately. The launcher runs
collection and the complete union through the existing absolute native verifier:

```text
E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\ig-native\Scripts\python.exe -B E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\integrator_verify.py --root <admitted target> --label <fresh label ending c or t> <all nine suite paths> [--collect-only] --runxfail -p _scratch.reliability_focused_guard -p _scratch.agw_heavy_import_guard -p _scratch.partition_receipt_plugin
```

Actual generated argv and environment-variable names are saved before each
phase. Provider secrets are removed and all application/temp/cache paths are
redirected. The ordinary live-index string is a lexical prohibition, never a
file to inspect. All network use, including port 5179, is denied in pytest.

After retaining the baseline failures, root can repair product source and write
a new admission with changed source hashes and a fresh worker label. Do not
modify any existing or new regression assertion to make it pass. A corrected
worker run needs its documented product repair. Reuse the exact instruments
only if their source review remains valid.

For the integrated checkout, bind its exact HEAD and final bytes, and the
successful worker's `expected-membership.json` path and SHA256. Then run:

```powershell
& 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-focused-node02\run-root.ps1' -Target checkout -Admission 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-root-checkout01.json'
```

Keep `runs/<target>-<label>`, `outer-receipts`, both target `_scratch/<label>c`
and `<label>t` verifier outputs, and both membership directories. Each Node child
has its own launch/input/output/exit record and permission receipt. Validate raw
pytest, verifier and outer exits, complete case IDs, subtests, JUnit counts,
heavy-import guard, lexical guard and Node receipts before assigning a result.
Expected baseline failures are still failures.

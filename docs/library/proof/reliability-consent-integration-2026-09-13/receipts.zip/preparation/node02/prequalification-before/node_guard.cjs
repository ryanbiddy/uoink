'use strict';
// Reviewed-source guard only. Node permissions/vm do not sandbox malicious code.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const Module = require('node:module');
const originalRead = fs.readFileSync.bind(fs);
const originalWrite = fs.writeFileSync.bind(fs);
const originalCreateContext = vm.createContext.bind(vm);
const originalRunInContext = vm.runInContext.bind(vm);
// Materialize stdio/console before denying module imports; the trusted harness
// uses these existing pipe handles for its JSON result and error reporting.
const existingStdout = process.stdout;
const existingStderr = process.stderr;
const existingConsole = console;
const expected = {
  dashboard: process.env.IG_NODE_DASHBOARD,
  dashboardSha: process.env.IG_NODE_DASHBOARD_SHA,
  harnessSha: process.env.IG_NODE_HARNESS_SHA,
  receipt: process.env.IG_NODE_RECEIPT,
  label: process.env.IG_NODE_LABEL,
};
const violations = [];
let stdinReads = 0, dashboardReads = 0, contextCount = 0, vmRuns = 0;
const contexts = new WeakSet();
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const canonical = value => path.resolve(String(value)).toLowerCase();
function deny(event, detail) {
  violations.push({ event, detail: detail === undefined ? null : String(detail) });
  throw new Error('Exact Node guard denied ' + event);
}
if (!expected.dashboard || !expected.receipt || !expected.label ||
    !/^[0-9a-f]{64}$/.test(expected.dashboardSha || '') ||
    !/^[0-9a-f]{64}$/.test(expected.harnessSha || '')) {
  throw new Error('Missing exact Node guard bindings');
}
if (process.version !== 'v24.18.0' || !process.permission ||
    !process.execArgv.includes('--permission')) {
  throw new Error('Unexpected Node runtime or permission mode');
}
const permissions = {
  allRead: process.permission.has('fs.read'),
  allWrite: process.permission.has('fs.write'),
  dashboardRead: process.permission.has('fs.read', expected.dashboard),
  receiptWrite: process.permission.has('fs.write', expected.receipt),
  child: process.permission.has('child'),
  worker: process.permission.has('worker'),
};
if (permissions.allRead || permissions.allWrite || permissions.child || permissions.worker ||
    !permissions.dashboardRead || !permissions.receiptWrite) {
  throw new Error('Unexpected Node permission grants');
}
const evalIndex = process.execArgv.indexOf('-e');
if (evalIndex < 0 || digest(process.execArgv[evalIndex + 1]) !== expected.harnessSha) {
  throw new Error('HARNESS bytes differ');
}
const sourceBytes = originalRead(expected.dashboard);
if (digest(sourceBytes) !== expected.dashboardSha) throw new Error('Dashboard bytes differ');
const page = sourceBytes.toString('utf8');
function block(startNeedle, endNeedle) {
  const start = page.indexOf(startNeedle);
  const end = page.indexOf(endNeedle, start + 1);
  if (start < 0 || end <= start) throw new Error('Missing exact dashboard block');
  return page.slice(start, end);
}
const expectedVmSource = block('    function humanLabel(value) {', '    function sourceStatusLabel(value)') + '\n' +
  block('    const TRANSCRIPT_MODEL_DOWNLOAD_MB = {', '    async function refreshSettings()');
const vmSourceSha = digest(expectedVmSource);
const fsFacade = Object.freeze({
  readFileSync(value, encoding) {
    if (encoding !== 'utf8') return deny('read encoding', encoding);
    if (value === 0) {
      stdinReads += 1;
      if (stdinReads !== 1) return deny('repeated stdin read');
      return originalRead(0, 'utf8');
    }
    if (typeof value !== 'string' || canonical(value) !== canonical(expected.dashboard)) {
      return deny('filesystem read', value);
    }
    dashboardReads += 1;
    if (dashboardReads !== 1) return deny('repeated dashboard read');
    const raw = originalRead(expected.dashboard);
    if (digest(raw) !== expected.dashboardSha) return deny('dashboard changed');
    return raw.toString('utf8');
  },
});
const vmFacade = Object.freeze({
  createContext(context, options) {
    if (options !== undefined || contextCount !== 0) return deny('unexpected VM context');
    const required = ['authFetch', 'confirm', 'console', 'els', 'refreshSettings', 'showToast'];
    if (JSON.stringify(Object.keys(context).sort()) !== JSON.stringify(required)) {
      return deny('unexpected VM seams');
    }
    contextCount += 1;
    const result = originalCreateContext(context, { codeGeneration: { strings: false, wasm: false } });
    contexts.add(result);
    return result;
  },
  runInContext(source, context, options) {
    if (!contexts.has(context) || source !== expectedVmSource || vmRuns !== 0 ||
        !options || options.timeout !== 1000 || Object.keys(options).length !== 1) {
      return deny('unexpected VM source or options');
    }
    vmRuns += 1;
    return originalRunInContext(source, context, { timeout: 1000 });
  },
});
function facade(name) {
  if (name === 'node:fs') return fsFacade;
  if (name === 'node:vm') return vmFacade;
  return deny('module load', name);
}
Module._load = function guardedLoad(name) { return facade(name); };
process.getBuiltinModule = function guardedBuiltin(name) { return facade(name); };
for (const name of ['binding', '_linkedBinding', 'dlopen', '_debugProcess', '_debugEnd', 'kill', 'chdir']) {
  process[name] = function deniedProcessOperation() { return deny('process.' + name); };
}
for (const name of ['fetch', 'WebSocket', 'EventSource']) {
  Object.defineProperty(globalThis, name, { configurable: false, writable: false,
    value: function deniedNetworkOperation() { return deny('global.' + name); } });
}
process.on('exit', code => {
  const sourceUnchanged = digest(originalRead(expected.dashboard)) === expected.dashboardSha;
  const valid = violations.length === 0 && sourceUnchanged && stdinReads === 1 &&
    dashboardReads === 1 && contextCount === 1 && vmRuns === 1;
  const receipt = {
    profile: 'exact-dashboard-vm-reviewed-source', label: expected.label, nodeVersion: process.version,
    actualExitCode: code, dashboardSha256: expected.dashboardSha, harnessSha256: expected.harnessSha,
    vmSourceSha256: vmSourceSha, permissions, violations, stdinReads, dashboardReads,
    contextCount, vmRuns, sourceUnchanged, valid,
    limits: 'Cooperative guard for exact reviewed source; no malicious-code sandbox, native/model or release qualification.',
  };
  originalWrite(expected.receipt, JSON.stringify(receipt, null, 2) + '\n', { encoding: 'utf8' });
});

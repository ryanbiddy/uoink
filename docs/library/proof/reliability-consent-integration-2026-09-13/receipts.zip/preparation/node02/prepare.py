"""Capture source text and build inert profile inputs; never run Node/product."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
out = Path(__file__).absolute().parent
root = out.parents[1]
prior = root / '_scratch/reliability-focused-instrument01'
worker = Path(r'C:\Users\hello\AppData\Local\AgentControlRoom\worktrees\uoink-library\0851b440-86a\grok')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
seal_raw = (prior / 'SHA256.json').read_bytes()
assert sha(seal_raw) == 'a06eee5c9ecc0b550b91dba9a930d91adfcb8588cc8ab68cf0be24f6e8dc2362'
manifest = json.loads(seal_raw)
assert manifest['payload_count'] == 31
for row in manifest['payloads']:
    raw = (prior / row['file']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
(out / 'ORIGINAL-PREPARATION31-SHA256.json').write_bytes(seal_raw)
for name in ['EXPECTED-INPUTS.json', 'run-root.ps1', 'reference/integrator_verify.py',
             'reference/agw_heavy_import_guard.py', 'reference/partition_receipt_plugin.py',
             'reference/partition_exit_contract.py', 'reference/pyvenv.cfg']:
    path = out / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write((prior / name).read_bytes())
captures = []
tests = ['tests/test_reliability_local_only_load.py', 'tests/test_reliability_model_readiness.py', 'tests/test_reliability_settings_ui.py']
for name in tests:
    raw = (worker / name).read_bytes()
    target = out / 'captures' / (Path(name).name + '.txt')
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream: stream.write(raw)
    captures.append({'source': str(worker / name), 'file': target.relative_to(out).as_posix(),
        'bytes': len(raw), 'sha256': sha(raw), 'provisional_worker_capture': True})
ui = ast.parse((out / 'captures/test_reliability_settings_ui.py.txt').read_bytes())
assignment = next(node for node in ui.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'HARNESS' for target in node.targets))
harness = ast.literal_eval(assignment.value)
assert isinstance(harness, str)
run = next(node for node in ui.body if isinstance(node, ast.FunctionDef) and node.name == '_run')
calls = [node for node in ast.walk(run) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'subprocess' and node.func.attr == 'run']
assert len(calls) == 1
call = calls[0]
assert isinstance(call.args[0], ast.List)
assert ast.literal_eval(call.args[0].elts[0]) == 'node' and ast.literal_eval(call.args[0].elts[1]) == '-e'
assert isinstance(call.args[0].elts[2], ast.Name) and call.args[0].elts[2].id == 'HARNESS'
assert {node.arg for node in call.keywords} == {'input', 'cwd', 'text', 'capture_output', 'timeout'}
(out / 'captured-harness.js.txt').write_bytes(harness.encode('utf-8'))
node = Path(r'C:\Program Files\nodejs\node.exe')
with node.open('rb') as stream:
    binary_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
assert node.stat().st_size == 92534088 and binary_sha == '9a4eb5f1c29c6a2e93852ead46b999e284a6a5ca8bab4d4e241d587d025a52de'
profile = {'prepared_utc': datetime.now(timezone.utc).isoformat(), 'status': 'PREPARED ONLY; NO NODE/TEST EXECUTION',
    'prior_manifest_sha256': sha(seal_raw), 'worker_root': str(worker), 'captures': captures,
    'node_executable': str(node), 'node_bytes': 92534088, 'node_sha256': binary_sha,
    'node_version_from_file_metadata': '24.18.0', 'node_version_process_executed': False,
    'harness_file': 'captured-harness.js.txt', 'harness_sha256': sha(harness.encode('utf-8')),
    'ui_test_sha256': captures[-1]['sha256'], 'actual_original_argv': ['node', '-e', '<exact HARNESS bytes>'],
    'stdout_stderr_and_stdin': 'Existing pipes; no arbitrary inherited descriptor admission',
    'intended_source_read': 'assets/dashboard/index.html in final reviewed target root; SHA comes from final root admission',
    'added_python_regression_files': tests, 'additional_root_regression': 'Must be named and hashed in final admission; same exact HARNESS may be reused',
    'source_executed_by_preparer': False}
(out / 'NODE-PROFILE.json').write_text(json.dumps(profile, indent=2)+'\n', encoding='utf-8', newline='\n')
(out / '.gitattributes').write_text('* -text\n', encoding='ascii', newline='\n')
print(json.dumps({'prior31_verified': True, 'new_regression_captures': len(captures), 'harness_sha256': profile['harness_sha256'], 'node_executed': False}))

"""Prepared focused launcher. Refuses absent final root admission; never run by author."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import ntpath
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

OUT = Path(__file__).resolve().parent
CHECKOUT = OUT.parents[1]
FIXED = ['tests/test_c02_reliability_faster_whisper.py', 'tests/test_cm11_asr_fallback.py',
         'tests/test_g20_humanized_copy.py', 'tests/test_g25_settings_polish.py', 'tests/test_whisper_cache_consent.py']
FROZEN = FIXED + ['whisper_runner.py', 'requirements.txt', 'build.ps1']
PRODUCT = ['uoink_reliability.py', 'server.py', 'assets/dashboard/index.html']
FORBIDDEN = r'C:\Users\hello\AppData\Local\Uoink\index.db'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n', encoding='utf-8', newline='\n')

def safe_relative(value):
    if not isinstance(value, str) or '\\' in value: raise ValueError('Use reviewed POSIX relative input paths')
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in ('..', '.', '') for part in path.parts) or ':' in value:
        raise ValueError('Input escapes target')
    return value

def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, text=True, encoding='utf-8').strip()

def input_hashes(root, names):
    return {name: sha((root / safe_relative(name)).read_bytes()) for name in names}

def require_hashes(root, expected):
    actual = input_hashes(root, expected)
    if actual != expected: raise RuntimeError('Reviewed input bytes differ')
    return actual

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--admission', required=True)
    parser.add_argument('--target', choices=['worker', 'checkout'], required=True)
    args = parser.parse_args()
    admission_path = Path(args.admission).absolute()
    admission_bytes = admission_path.read_bytes()
    admission = json.loads(admission_bytes)
    if admission.get('root_reviewed') is not True or not admission.get('review_document'):
        raise RuntimeError('Final patch/root review not supplied; preparation only')
    if admission.get('node_or_other_child_processes_required') is not True or admission.get('node_profile_reviewed') is not True:
        raise RuntimeError('Exact Node source/permission/adapter profile requires root review')
    if admission.get('added_nonpython_regression_files'):
        raise RuntimeError('Every added non-Python regression needs its separate reviewed execution profile')
    added = admission.get('added_python_regression_files')
    if not isinstance(added, list) or not added or len(added) != len(set(added)):
        raise RuntimeError('Final added regression files are required')
    for name in added:
        safe_relative(name)
        if not name.startswith('tests/test_') or not name.endswith('.py') or name in FIXED:
            raise RuntimeError('Invalid added Python regression selection')
    if set(added) != {
        'tests/test_reliability_local_only_load.py', 'tests/test_reliability_model_readiness.py',
        'tests/test_reliability_settings_ui.py', 'tests/test_reliability_review_boundaries.py'}:
        raise RuntimeError('The four reviewed new regression files are required')
    target = admission['targets'][args.target]
    root_text = target['root']
    if not isinstance(root_text, str) or not ntpath.isabs(root_text) or 'uoink/index.db' in root_text.replace('\\', '/').lower():
        raise ValueError('Invalid target root')
    root = Path(root_text).resolve()
    if args.target == 'checkout' and root != CHECKOUT: raise RuntimeError('Wrong integrator checkout')
    label = target['label']
    if not re.fullmatch(r'rl[wc][0-9]{2}', label): raise ValueError('Use a fresh short reviewed label')
    expected_head = target['source_commit']
    if not re.fullmatch(r'[0-9a-f]{40}', expected_head): raise ValueError('Missing exact source commit')
    if git(root, 'rev-parse', 'HEAD') != expected_head: raise RuntimeError('Source commit differs from review')
    expected = target['reviewed_files']
    if not isinstance(expected, dict) or not set(FROZEN + PRODUCT + added).issubset(expected):
        raise RuntimeError('Final source/test union is not completely bound')
    if not all(isinstance(value, str) and re.fullmatch(r'[0-9a-f]{64}', value) for value in expected.values()):
        raise ValueError('Missing exact reviewed file hash')
    baseline = json.loads((OUT / 'EXPECTED-INPUTS.json').read_text(encoding='utf-8'))
    baseline_hashes = {row['file']: row['sha256'] for row in baseline['bindings']}
    require_hashes(root, expected)
    for name in FROZEN:
        if expected[name] != baseline_hashes[name]: raise RuntimeError('Frozen source or existing test changed: ' + name)
    modified_tests = git(root, 'diff', 'HEAD', '--name-only', '--diff-filter=CDMRTUXB', '--', 'tests')
    if modified_tests: raise RuntimeError('Existing test edits require a separate decision: ' + modified_tests)
    if (root / 'bin/torchcodec').exists():
        raise RuntimeError('Target carries a packaged decoder directory; native startup scope is not admitted')
    instruments = admission['instrument_hashes']
    required_instruments = ['launch.py', 'reliability_focused_guard.py', 'EXPECTED-INPUTS.json', 'BRIEF.md',
        'reference/integrator_verify.py', 'reference/agw_heavy_import_guard.py',
        'reference/partition_receipt_plugin.py', 'reference/partition_exit_contract.py',
        'node_guard.cjs', 'NODE-PROFILE.json', 'captured-harness.js.txt']
    if set(instruments) != set(required_instruments): raise RuntimeError('Instrument review is incomplete')
    require_hashes(OUT, instruments)
    verifier = CHECKOUT / '_scratch/integrator_verify.py'
    if sha(verifier.read_bytes()) != instruments['reference/integrator_verify.py']:
        raise RuntimeError('Absolute checkout verifier differs from reviewed version')
    native = CHECKOUT / '_scratch/ig-native/Scripts/python.exe'
    if sha((CHECKOUT / '_scratch/ig-native/pyvenv.cfg').read_bytes()) != baseline['pyvenv_cfg_sha256']:
        raise RuntimeError('Qualified native-venv configuration changed')

    destination = OUT / 'runs' / (args.target + '-' + label)
    destination.mkdir(parents=True, exist_ok=False)
    (destination / 'root-admission.json').write_bytes(admission_bytes)
    plugin_inputs = {
        'agw_heavy_import_guard.py': OUT / 'reference/agw_heavy_import_guard.py',
        'partition_receipt_plugin.py': OUT / 'reference/partition_receipt_plugin.py',
        'reliability_focused_guard.py': OUT / 'reliability_focused_guard.py',
    }
    plugin_receipt = []
    for name, source in plugin_inputs.items():
        path = root / '_scratch' / name
        path.parent.mkdir(exist_ok=True)
        raw = source.read_bytes()
        if path.exists():
            if path.read_bytes() != raw: raise RuntimeError('Refuse instrument overwrite: ' + str(path))
            action = 'reused-identical'
        else:
            with path.open('xb') as stream: stream.write(raw)
            action = 'copied-exact-reviewed-text'
        plugin_receipt.append({'path': str(path), 'sha256': sha(raw), 'action': action})
    spec = importlib.util.spec_from_file_location('qualified_focus_receipt_contract', OUT / 'reference/partition_exit_contract.py')
    contract = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(contract)
    selectors = FIXED + added
    save(destination / 'plan.json', {'target': args.target, 'root': str(root), 'source_commit': expected_head,
        'selectors': selectors, 'reviewed_files': expected, 'instrument_hashes': instruments,
        'plugin_inputs': plugin_receipt, 'started_utc': datetime.now(timezone.utc).isoformat(),
        'guard_scope': 'Real heavy imports, network and packaged DLL registration blocked; only exact reviewed Node VM child allowed; temporary data only.'})

    expected_membership = None
    runs = []
    for phase, extra in [('collection', ['--collect-only']), ('tests', [])]:
        phase_label = label + ('c' if phase == 'collection' else 't')
        scratch = root / '_scratch' / phase_label
        observer = root / '_scratch' / (phase_label + '-membership')
        if scratch.exists() or observer.exists() or (root / '_scratch' / (phase_label + '-0')).exists():
            raise RuntimeError('Run label is not fresh')
        node_output = destination / (phase + '-node')
        node_output.mkdir(exist_ok=False)
        env = os.environ.copy()
        removed = []
        for key in list(env):
            upper = key.upper()
            if (re.search('API_?KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|BASE_URL', upper)
                or upper.startswith(('ANTHROPIC_', 'OPENAI_', 'GOOGLE_API_', 'GEMINI_API_', 'XAI_', 'GROK_', 'CLAUDE_CODE_USE_', 'UOINK_ISOLATED_'))
                or upper in {'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'PYTHONPATH', 'PYTHONHOME', 'PYTEST_ADDOPTS', 'PYTEST_PLUGINS', 'NODE_OPTIONS', 'NODE_PATH'}):
                removed.append(key)
                env.pop(key)
        env.update(LOCALAPPDATA=r'C:\Users\hello\AppData\Local', IG_FORBIDDEN_LIVE=FORBIDDEN,
            HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1', PYTHONDONTWRITEBYTECODE='1',
            HF_HOME=str(scratch / 'hf'), HF_HUB_CACHE=str(scratch / 'hf/hub'),
            HUGGINGFACE_HUB_CACHE=str(scratch / 'hf/hub'), TRANSFORMERS_CACHE=str(scratch / 'hf/transformers'),
            TORCH_HOME=str(scratch / 'torch'), XDG_CACHE_HOME=str(scratch / 'cache'),
            HOME=str(scratch), USERPROFILE=str(scratch),
            AGW_HEAVY_GUARD_RECEIPT=str(destination / (phase + '-heavy.json')),
            IG_PARTITION_RECEIPT_PATH=str(observer),
            IG_FOCUSED_ROOT=str(root), IG_FOCUSED_LABEL=phase_label,
            IG_FOCUSED_GUARD_RECEIPT=str(destination / (phase + '-focused.json')),
            IG_NODE_PROFILE=str(OUT / 'NODE-PROFILE.json'),
            IG_NODE_PRELOAD=str(OUT / 'node_guard.cjs'),
            IG_NODE_PRELOAD_SHA=instruments['node_guard.cjs'],
            IG_NODE_OUTPUT=str(node_output),
            IG_NODE_DASHBOARD_SHA=expected['assets/dashboard/index.html'])
        command = [str(native), '-B', str(verifier), '--root', str(root), '--label', phase_label,
            *selectors, *extra, '--runxfail', '-p', '_scratch.reliability_focused_guard',
            '-p', '_scratch.agw_heavy_import_guard', '-p', '_scratch.partition_receipt_plugin']
        save(destination / (phase + '-launch-plan.json'), {'command': command, 'cwd': str(root),
            'scrubbed_variable_names': sorted(removed), 'data_directory': str(scratch)})
        with (destination / (phase + '-launcher.log')).open('x', encoding='utf-8', newline='\n') as stream:
            code = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
        # Persist the actual exit before any receipt validation can fail.
        row = {'phase': phase, 'actual_verifier_exit': code, 'command': command, 'scratch': str(scratch), 'observer': str(observer)}
        runs.append(row)
        save(destination / 'raw-exits.json', runs)
        require_hashes(root, expected)
        require_hashes(OUT, instruments)
        if git(root, 'rev-parse', 'HEAD') != expected_head: raise RuntimeError('Source changed during verification')
        verifier_results = json.loads((scratch / 'results.json').read_text(encoding='utf-8'))
        if len(verifier_results) != 1 or verifier_results[0]['name'] != 'tests': raise RuntimeError('Expected one raw pytest command')
        raw_exit = verifier_results[0]['exit']
        heavy = json.loads((destination / (phase + '-heavy.json')).read_text(encoding='utf-8'))
        heavy_validation = contract.validate_heavy_guard(heavy, raw_exit)
        focused = json.loads((destination / (phase + '-focused.json')).read_text(encoding='utf-8'))
        if focused['pytest_exitstatus'] != raw_exit or not focused['valid'] or focused['violations'] or not focused['lexical_wrappers_installed_at_finish']:
            raise RuntimeError('Focused guard invalid; retain raw outcome')
        if not focused['node']['valid'] or not focused['node']['inputs_unchanged'] or not focused['node']['adapter_installed_at_finish']:
            raise RuntimeError('Exact Node adapter/child receipts invalid')
        if phase == 'collection' and focused['node']['child_count'] != 0:
            raise RuntimeError('Node process during collection was not admitted')
        if phase == 'tests' and focused['node']['child_count'] == 0:
            raise RuntimeError('UI execution produced no Node receipts')
        selected = json.loads((observer / 'membership.json').read_text(encoding='utf-8'))
        session = json.loads((observer / 'session.json').read_text(encoding='utf-8'))
        if not selected or len(selected) != len(set(selected)): raise RuntimeError('Empty or duplicate collected case IDs')
        if {node.split('::')[0] for node in selected} != set(selectors):
            raise RuntimeError('Collected files differ from complete reviewed union')
        if phase == 'collection':
            if code != 0 or raw_exit != 0 or session != {'exit': 0, 'tests_collected': len(selected), 'tests_failed': 0, 'reports': 0}:
                raise RuntimeError('Collection did not complete; no test run follows')
            expected_membership = selected
            save(destination / 'expected-membership.json', selected)
            if args.target == 'checkout':
                worker_path = Path(admission['worker_expected_membership_path']).absolute()
                worker_bytes = worker_path.read_bytes()
                if sha(worker_bytes) != admission['worker_expected_membership_sha256'] or set(json.loads(worker_bytes)) != set(selected):
                    raise RuntimeError('Worker/checkout case membership differs')
        else:
            if set(selected) != set(expected_membership): raise RuntimeError('Execution membership differs from collection')
            reports = [json.loads(line) for line in (observer / 'reports.jsonl').read_text(encoding='utf-8').splitlines()]
            checked = contract.validate_partition(selected=selected, reports=reports, session=session,
                verifier_results=verifier_results, outer_exit=code, junit_xml=(scratch / 'tests.xml').read_bytes())
            save(destination / 'validated-results.json', checked)
            save(destination / 'summary.json', {'source_commit': expected_head, 'root': str(root),
                'counts': checked['counts'], 'top_level_cases': checked['case_count'],
                'subtest_counts': checked['subtest_counts'], 'subtest_count': checked['subtest_count'],
                'junit': checked['junit'], 'actual_pytest_exit': raw_exit, 'actual_verifier_exit': code,
                'heavy_guard': heavy_validation, 'focused_guard': focused, 'inputs_unchanged': True,
                'complete_membership': True, 'finished_utc': datetime.now(timezone.utc).isoformat()})
        if phase == 'tests': return code
    raise RuntimeError('No execution phase')

if __name__ == '__main__':
    raise SystemExit(main())

"""Data-only preparation: copy text, derive instruments, parse Python; no tests or Node."""
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PRIOR = ROOT / '_scratch/reliability-focused-instrument01'
WORKER = Path(r'C:\Users\hello\AppData\Local\AgentControlRoom\worktrees\uoink-library\0851b440-86a\grok')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def put(name, text):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
def save(name, value):
    put(name, json.dumps(value, indent=2, ensure_ascii=False)+'\n')
def replace_one(source, before, after):
    assert source.count(before) == 1, before
    return source.replace(before, after)
def patch(name, before, after):
    put('instrument-diffs/'+name+'.patch', ''.join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile='preparation31/'+name, tofile='node02/'+name)))

old_guard = (PRIOR / 'reliability_focused_guard.py').read_text(encoding='utf-8')
adapter = (OUT / 'node_adapter.txt').read_text(encoding='utf-8')
guard = replace_one(old_guard, 'def audit(event, args):', adapter+'\n\ndef audit(event, args):')
guard = replace_one(guard, "    if event.startswith('socket.') or event in {", "    if event == 'subprocess.Popen' and admit_node_audit(args):\n        return\n    if event.startswith('socket.') or event in {")
guard = replace_one(guard, "    receipt = {'profile': 'reliability-focused-no-network-or-child-process',", "    node = node_finish()\n    receipt = {'profile': 'reliability-focused-exact-node-vm',\n        'node': node,")
guard = replace_one(guard, "'valid': installed and not EVENTS,", "'valid': installed and not EVENTS and node['valid'],")
put('reliability_focused_guard.py', guard)
patch('reliability_focused_guard.py', old_guard, guard)

old_launch = (PRIOR / 'launch.py').read_text(encoding='utf-8')
launch = replace_one(old_launch,
    "    if admission.get('node_or_other_child_processes_required') is not False:\n        raise RuntimeError('Exact Node/new-child profile remains unreviewed; do not omit required tests')",
    "    if admission.get('node_or_other_child_processes_required') is not True or admission.get('node_profile_reviewed') is not True:\n        raise RuntimeError('Exact Node source/permission/adapter profile requires root review')")
launch = replace_one(launch, "    target = admission['targets'][args.target]", "    if set(added) != {\n        'tests/test_reliability_local_only_load.py', 'tests/test_reliability_model_readiness.py',\n        'tests/test_reliability_settings_ui.py', 'tests/test_reliability_review_boundaries.py'}:\n        raise RuntimeError('The four reviewed new regression files are required')\n    target = admission['targets'][args.target]")
launch = replace_one(launch,
    "        'reference/partition_receipt_plugin.py', 'reference/partition_exit_contract.py']",
    "        'reference/partition_receipt_plugin.py', 'reference/partition_exit_contract.py',\n        'node_guard.cjs', 'NODE-PROFILE.json', 'captured-harness.js.txt']")
launch = replace_one(launch,
    "'guard_scope': 'Real heavy imports, network, subprocesses and packaged DLL registration blocked in pytest; temporary data only.'",
    "'guard_scope': 'Real heavy imports, network and packaged DLL registration blocked; only exact reviewed Node VM child allowed; temporary data only.'")
launch = replace_one(launch,
    "        env = os.environ.copy()",
    "        node_output = destination / (phase + '-node')\n        node_output.mkdir(exist_ok=False)\n        env = os.environ.copy()")
launch = replace_one(launch,
    "            IG_FOCUSED_GUARD_RECEIPT=str(destination / (phase + '-focused.json')))",
    "            IG_FOCUSED_GUARD_RECEIPT=str(destination / (phase + '-focused.json')),\n            IG_NODE_PROFILE=str(OUT / 'NODE-PROFILE.json'),\n            IG_NODE_PRELOAD=str(OUT / 'node_guard.cjs'),\n            IG_NODE_PRELOAD_SHA=instruments['node_guard.cjs'],\n            IG_NODE_OUTPUT=str(node_output),\n            IG_NODE_DASHBOARD_SHA=expected['assets/dashboard/index.html'])")
launch = replace_one(launch,
    "        selected = json.loads((observer / 'membership.json').read_text(encoding='utf-8'))",
    "        if not focused['node']['valid'] or not focused['node']['inputs_unchanged'] or not focused['node']['adapter_installed_at_finish']:\n            raise RuntimeError('Exact Node adapter/child receipts invalid')\n        if phase == 'collection' and focused['node']['child_count'] != 0:\n            raise RuntimeError('Node process during collection was not admitted')\n        if phase == 'tests' and focused['node']['child_count'] == 0:\n            raise RuntimeError('UI execution produced no Node receipts')\n        selected = json.loads((observer / 'membership.json').read_text(encoding='utf-8'))")
put('launch.py', launch)
patch('launch.py', old_launch, launch)

# Preserve the original provisional profile before documenting the final snapshot.
profile = json.loads((OUT / 'NODE-PROFILE.json').read_text(encoding='utf-8'))
(OUT / 'PROVISIONAL-NODE-PROFILE.json').write_bytes((OUT / 'NODE-PROFILE.json').read_bytes())
added = profile['added_python_regression_files'] + ['tests/test_reliability_review_boundaries.py']
for row in profile['captures']:
    assert (OUT / row['file']).read_bytes() == Path(row['source']).read_bytes()
new_name = added[-1]
raw = (WORKER / new_name).read_bytes()
capture_name = 'captures/test_reliability_review_boundaries.py.txt'
(OUT / capture_name).write_bytes(raw)
profile['captures'].append({'source': str(WORKER/new_name), 'file': capture_name,
    'bytes': len(raw), 'sha256': sha(raw), 'root_authored_regression': True})
profile['finished_worker_rechecked_utc'] = datetime.now(timezone.utc).isoformat()
profile['added_python_regression_files'] = added
profile['additional_root_regression'] = new_name
profile['all_four_regression_captures_match_finished_worker'] = True
(OUT / 'NODE-PROFILE.json').write_text(json.dumps(profile, indent=2)+'\n', encoding='utf-8', newline='\n')

bindings = json.loads((PRIOR / 'EXPECTED-INPUTS.json').read_text(encoding='utf-8'))
fixed = ['tests/test_c02_reliability_faster_whisper.py', 'tests/test_cm11_asr_fallback.py',
    'tests/test_g20_humanized_copy.py', 'tests/test_g25_settings_polish.py', 'tests/test_whisper_cache_consent.py']
frozen = fixed + ['whisper_runner.py', 'requirements.txt', 'build.ps1']
names = frozen + ['uoink_reliability.py', 'server.py', 'assets/dashboard/index.html'] + added
worker_files = {name: sha((WORKER/name).read_bytes()) for name in names}
baseline = {row['file']: row['sha256'] for row in bindings['bindings']}
assert all(worker_files[name] == baseline[name] for name in frozen)
save('FINISHED-WORKER-BINDINGS.json', {'captured_utc': datetime.now(timezone.utc).isoformat(),
    'root': str(WORKER), 'source_commit': 'ROOT MUST BIND EXACT HEAD AT ADMISSION',
    'reviewed_files': worker_files, 'existing_frozen_bytes_unchanged': True,
    'source_or_tests_executed': False})
instruments = ['launch.py', 'reliability_focused_guard.py', 'EXPECTED-INPUTS.json', 'BRIEF.md',
    'reference/integrator_verify.py', 'reference/agw_heavy_import_guard.py',
    'reference/partition_receipt_plugin.py', 'reference/partition_exit_contract.py',
    'node_guard.cjs', 'NODE-PROFILE.json', 'captured-harness.js.txt']
template = {'root_reviewed': False, 'node_profile_reviewed': False,
    'review_document': 'ROOT MUST WRITE THE EXACT SOURCE/PATCH/INSTRUMENT REVIEW',
    'node_or_other_child_processes_required': True, 'added_nonpython_regression_files': [],
    'added_python_regression_files': added,
    'instrument_hashes': {name: sha((OUT/name).read_bytes()) for name in instruments},
    'targets': {'worker': {'root': str(WORKER), 'label': 'rlw01',
        'source_commit': 'ROOT MUST BIND EXACT 40-CHARACTER COMMIT', 'reviewed_files': worker_files},
        'checkout': {'root': str(ROOT), 'label': 'rlc01',
        'source_commit': 'ROOT MUST BIND THE POST-INTEGRATION COMMIT',
        'reviewed_files': worker_files}},
    'worker_expected_membership_path': 'ROOT MUST BIND SUCCESSFUL WORKER COLLECTION RECEIPT',
    'worker_expected_membership_sha256': 'ROOT MUST HASH EXACT WORKER MEMBERSHIP',
    'preparation_only': True,
    'baseline_expectation': 'Two known product failures in the main union; not a measured result. No xfail, skip or suppression.'}
save('ROOT-ADMISSION.TEMPLATE.json', template)
parsed = []
for name in ['launch.py', 'reliability_focused_guard.py', 'materialize.py']:
    ast.parse((OUT/name).read_text(encoding='utf-8'), filename=str(OUT/name))
    parsed.append(name)
save('STATIC-PREPARATION.json', {'python_files_parsed_only': parsed, 'parse_success': True,
    'node_executed': False, 'pytest_executed': False, 'product_imported': False,
    'old31_inputs_unchanged': True, 'new_regression_files_bound': len(added),
    'checks': 'AST syntax only; not Python/Node execution qualification'})
print(json.dumps({'prepared': True, 'node_executed': False, 'tests_executed': False,
    'instruments': template['instrument_hashes']}))

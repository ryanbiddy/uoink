# Exact Node VM profile preparation — 2026-09-13

Prepare a separate derivative of the sealed 31-payload focused instrument.
Preserve that seal and all existing product/test bytes. Do not launch Node,
pytest, product imports, model packages or an installer. Root must review this
exact source and the completed worker patch before any execution.

The worker UI test calls `subprocess.run(["node", "-e", HARNESS], ...)` with
JSON on stdin, ROOT as cwd, captured text stdout/stderr and a 15-second timeout.
The exact harness reads stdin and assets/dashboard/index.html, extracts the
humanLabel and transcript-model helper blocks, and executes them with fake
DOM, confirm, authFetch, toast and refresh functions. Its assertions remain
unchanged. Include the five original suites, all three worker regression files
and the additional root-authored Python regression when named.

Bind the existing executable C:\Program Files\nodejs\node.exe by path,
92,534,088 bytes and SHA256
9a4eb5f1c29c6a2e93852ead46b999e284a6a5ca8bab4d4e241d587d025a52de.
File version metadata says 24.18.0; no version process has been launched.
Use Node's version-bound permission documentation to prepare flags.

The derivative Python plugin permits only the exact captured HARNESS argument
bytes, current admitted dashboard/UI-test hashes and reviewed cwd. It replaces
the bare executable with its absolute bound path and adds fixed permission and
preload arguments. This is an explicit launch-environment adaptation, with no
test/source/assertion change. Every other subprocess remains denied. Record
requested and actual argv, child input/output, actual exit and guard receipt.

The preload permits only stdin and the admitted dashboard text through a small
fs facade, and only the exact extracted source through a VM facade. Preserve
the test's fake DOM/fetch/confirm objects. Restrict file reads to dashboard and
preload, writes to one fresh receipt, and grant no child/worker/addon/WASI/
inspector permission. Deny network modules/globals, additional module loads,
native binding entry points and process-control calls. Report violations and
permission state. Preserve raw failures; never turn an invalid guard into a pass.

These are cooperative guards for reviewed source. Node's permission model and
vm are not a security boundary for malicious code, and no such claim follows.
Use quiescent reviewed paths, validate hashes before/after, and retain this
TOCTOU limit. No model-runtime or market acceptance follows from Node VM tests.

Source/test captures made while Grok is running are provisional. Recheck the
finished patch before root admission. Root will preserve worker test assertions
and add independent regressions for complete redirected cache targets and the
cross-model missing-size fallback. Do not rewrite the worker HARNESS for them.

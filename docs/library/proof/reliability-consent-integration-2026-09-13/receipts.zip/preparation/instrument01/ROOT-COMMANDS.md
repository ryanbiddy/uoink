# Root-run commands, pending final patch review

Use the existing CPython3.14 launcher and qualified native verification venv.
Do not use the private Python3.13 package-build runtime. Copy the template to a
new admission JSON under the checkout scratch directory, fill every field from
the reviewed final patch, and set root_reviewed only after reviewing the exact
source, fixtures, plugin and launch commands. Keep the original template intact.

Worker command in PowerShell:

```powershell
& 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-focused-instrument01\run-root.ps1' -Target worker -Admission 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-focused-instrument01\ROOT-ADMISSION.worker.json'
```

After worker qualification and reviewed integration, create a separate checkout
admission binding its exact source commit/bytes and the worker membership file's
SHA256. Run:

```powershell
& 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-focused-instrument01\run-root.ps1' -Target checkout -Admission 'E:\AI\projects\uoink\checkouts\Yoink-library\_scratch\reliability-focused-instrument01\ROOT-ADMISSION.checkout.json'
```

Each command performs one focused collection and one focused execution. No full
tree is requested. Read the raw console, JUnit, verifier exit, both guard receipts
and typed case reports. Preserve any failure and write its repair brief before
choosing fresh labels. A completed result reports the source commit, top-level
case counts, subtest counts and exact membership. The default labels rlw01 and
rlc01 are unused proposals; preparation has launched nothing.

The worker's final new tests may require a Node VM child. These commands refuse
that unresolved profile; root must review and complete its instrumentation
before running, while retaining every new regression in scope.

"""Syntax/text binding only; do not import proposed plugins or launch tests."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
out = Path(__file__).absolute().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
baseline = json.loads((out / 'EXPECTED-INPUTS.json').read_text(encoding='utf-8'))
syntax = []
for name in ('prepare.py', 'reliability_focused_guard.py', 'launch.py', 'static-review-and-seal.py'):
    raw = (out / name).read_bytes()
    compile(ast.parse(raw), str(out / name), 'exec')
    syntax.append({'file': name, 'sha256': sha(raw), 'bytes': len(raw), 'executed': False})
for row in baseline['bindings']:
    path = out / ('reference/' + Path(row['file']).name if row['kind'] == 'qualified-instrument' else 'before/' + row['file'])
    raw = path.read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
required = ['launch.py', 'reliability_focused_guard.py', 'EXPECTED-INPUTS.json', 'BRIEF.md',
    'reference/integrator_verify.py', 'reference/agw_heavy_import_guard.py',
    'reference/partition_receipt_plugin.py', 'reference/partition_exit_contract.py']
hashes = {name: sha((out / name).read_bytes()) for name in required}
template = {'root_reviewed': False, 'review_document': None, 'instrument_hashes': hashes,
    'added_python_regression_files': None, 'added_nonpython_regression_files': None,
    'node_or_other_child_processes_required': None,
    'worker_expected_membership_path': None, 'worker_expected_membership_sha256': None,
    'targets': {'worker': {'root': None, 'source_commit': None, 'label': 'rlw01', 'reviewed_files': {}},
        'checkout': {'root': baseline['root'], 'source_commit': None, 'label': 'rlc01', 'reviewed_files': {}}}}
(out / 'ROOT-ADMISSION.TEMPLATE.json').write_text(json.dumps(template, indent=2)+'\n', encoding='utf-8', newline='\n')
profile = {'prepared_utc': datetime.now(timezone.utc).isoformat(), 'qualification': 'NOT RUN; ROOT REVIEW AND FINAL PATCH REQUIRED',
    'native_python': baseline['native_python'], 'root_launcher_python': r'C:\Python314\python.exe -I -S -B',
    'fixed_selectors': [row['file'] for row in baseline['bindings'] if row['file'].startswith('tests/')],
    'collection_and_execution': 'One each per root, --runxfail, exact case membership and subtest-aware raw reconciliation',
    'references_unchanged': True, 'syntax_only': syntax, 'pytest_plugin_executed': False, 'product_imported': False,
    'open_inputs': ['Final worker root/commit/source hashes and added regression files', 'Exact Node VM profile if required by new tests'],
    'forbidden_live': r'C:\Users\hello\AppData\Local\Uoink\index.db', 'forbidden_live_string_only_no_access': True,
    'child_process_policy': 'Deny every subprocess within pytest; no speculative Node exception',
    'guards': ['Original generated sitecustomize', 'Exact heavy-import blocker', 'New lexical metadata/network/process/DLL-registration guard'],
    'root_entry_point': 'run-root.ps1', 'prepared_instrument_hashes': hashes}
(out / 'PROFILE.json').write_text(json.dumps(profile, indent=2)+'\n', encoding='utf-8', newline='\n')
rows = []
for path in sorted(out.rglob('*')):
    if not path.is_file() or path.name == 'SHA256.json': continue
    raw = path.read_bytes()
    rows.append({'file': path.relative_to(out).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
raw = (json.dumps({'created_utc': datetime.now(timezone.utc).isoformat(), 'payload_count': len(rows),
    'scope': 'Unexecuted focused instrumentation preparation and exact source/instrument text only', 'payloads': rows}, indent=2)+'\n').encode()
(out / 'SHA256.json').write_bytes(raw)
print(json.dumps({'payload_count': len(rows), 'manifest_sha256': sha(raw), 'syntax_only': syntax, 'tests_run': False}))

# Focused reliability verification preparation — 2026-09-13

Prepare instrumentation only. Do not launch pytest, import product modules,
execute a model, run Node, or inspect an installed client. The final Grok patch
and its added regression files have not yet been named. This preparation grants
no test or product acceptance.

The future root-run union is C02 reliability, CM11 ASR fallback, G20 humanized
copy, G25 settings polish, whisper cache consent, and every added Python
regression file in the reviewed patch. Preserve all existing assertions and
fixtures. Collect the exact union once, then execute it once with --runxfail
in the worker and again after integration in the checkout. Retain all case
IDs, typed phase/subtest reports, JUnit, raw logs and actual exits. Compare
membership across roots; distinguish top-level cases from passed subtests.

Reuse the qualified native verifier, heavy-import blocker, membership observer
and subtest-aware pure receipt validator byte-for-byte. Use the existing
checkout `_scratch/ig-native/Scripts/python.exe`, whose retained pyvenv.cfg
names CPython 3.14.6. Do not use the private Python3.13 model-runtime directory.
Copy only the exact reviewed pytest plugin text into a target's `_scratch`
when root launches; refuse to overwrite a different existing instrument.

The new focused plugin checks the forbidden live-library path lexically before
open/stat/lstat/realpath/readlink operations. It also denies all socket activity,
real subprocesses, OS launch calls and packaged model DLL registration in this
test process. Existing tests' own inert mocks remain available. This cooperative
Python guard adds no OS sandbox or native-runtime qualification. Keep the
original verifier's generated sitecustomize and temporary-path fixture unchanged.

The launcher requires a separate, completed root-admission JSON binding the
final target root, source commit, every source/test input hash and exact added
regression paths. The template remains unapproved. It records the commit and
input hashes before and after each phase, scrubs provider credentials and proxy/
Python/Node startup variables, forces offline flags and redirects cache/home
paths into the fresh verifier directory. Never resolve or stat the forbidden
live path; retain it only as the exact environment string.

Existing C02 tests inject segment streams; CM11 imports server but mocks ASR,
yt-dlp, ffmpeg and capture side effects; G20 reads dashboard text; G25 uses a
fake folder picker; cache-consent tests execute selected AST with fake models.
The server import reaches the runner's optional WhisperX probe, so the explicit
heavy-import blocker must be loaded before collection. No real model module
may load. Check target `bin/torchcodec` absence before launch; its presence
requires a separate reviewed decision, not a fake successful DLL setup.

Future Node VM tests are an unresolved instrumentation input. This proposed
profile permits no child processes. Before root admits the final union, inspect
all added tests. If a test invokes Node, bind its exact script/arguments and
prepare a separately reviewed Node permission/offline profile; do not run this
union under a broader process allowance or silently omit the new test. Missing
worker paths or a Node profile are preparation gaps, not failed measurements.

No product, existing test, model pin, staging, handoff, website or marketing file
changes. No new runtime installation, package/artifact fetch, commit or push.

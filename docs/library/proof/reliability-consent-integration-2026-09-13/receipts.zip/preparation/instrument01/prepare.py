"""Read/copy exact text inputs and hashes only; do not import any product code."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
out = Path(__file__).absolute().parent
root = out.parents[1]
sources = ['uoink_reliability.py', 'server.py', 'assets/dashboard/index.html', 'whisper_runner.py',
    'tests/test_c02_reliability_faster_whisper.py', 'tests/test_cm11_asr_fallback.py',
    'tests/test_g20_humanized_copy.py', 'tests/test_g25_settings_polish.py', 'tests/test_whisper_cache_consent.py',
    'requirements.txt', 'build.ps1', 'uoink_install_isolation.py', '_platform.py',
    'docs/library/RELIABILITY-CONSENT-SETTINGS-REPAIR-BRIEF-2026-09-13.md']
instruments = ['integrator_verify.py', 'agw_heavy_import_guard.py', 'partition_receipt_plugin.py', 'partition_exit_contract.py']
rows = []
for relative in sources:
    raw = (root / relative).read_bytes()
    destination = out / 'before' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream: stream.write(raw)
    rows.append({'file': relative, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'kind': 'source-before'})
for name in instruments:
    raw = (root / '_scratch' / name).read_bytes()
    destination = out / 'reference' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream: stream.write(raw)
    rows.append({'file': '_scratch/' + name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'kind': 'qualified-instrument'})
raw = (root / '_scratch/ig-native/pyvenv.cfg').read_bytes()
(out / 'reference/pyvenv.cfg').write_bytes(raw)
receipt = {'prepared_utc': datetime.now(timezone.utc).isoformat(), 'root': str(root), 'bindings': rows,
    'native_python': str(root / '_scratch/ig-native/Scripts/python.exe'),
    'pyvenv_cfg_sha256': hashlib.sha256(raw).hexdigest(), 'tests_or_product_imports_executed': False,
    'worker_patch': None, 'new_regression_files': None,
    'open_instrument_input': 'Whether final new UI regressions invoke Node; child processes denied pending exact separate review.'}
(out / 'EXPECTED-INPUTS.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8', newline='\n')
(out / '.gitattributes').write_text('* -text\n', encoding='ascii', newline='\n')
print(json.dumps({'copied_source_texts': len(sources), 'qualified_instruments': len(instruments), 'test_launch': False}))

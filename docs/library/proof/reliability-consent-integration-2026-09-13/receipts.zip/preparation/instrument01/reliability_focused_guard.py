"""Focused cooperative Python guard; preserves product and test behavior."""
import json
import ntpath
import os
from pathlib import Path
import sys

FORBIDDEN = r'C:\Users\hello\AppData\Local\Uoink\index.db'
assert os.environ['IG_FORBIDDEN_LIVE'] == FORBIDDEN
assert os.environ['HF_HUB_OFFLINE'] == '1'
assert os.environ['TRANSFORMERS_OFFLINE'] == '1'
assert os.environ['HF_DATASETS_OFFLINE'] == '1'
ROOT = os.environ['IG_FOCUSED_ROOT']
LABEL = os.environ['IG_FOCUSED_LABEL']
DESTINATION = os.environ['IG_FOCUSED_GUARD_RECEIPT']
EVENTS = []

def lexical(value):
    if not isinstance(value, (str, bytes, os.PathLike)): return None
    text = os.fsdecode(value).replace('/', '\\')
    if text.startswith('\\\\?\\'): text = text[4:]
    elif text.startswith('\\??\\'): text = text[4:]
    return ntpath.normcase(ntpath.abspath(text))

LIVE_DIRECTORY = ntpath.dirname(lexical(FORBIDDEN))
EXPECTED_DATA = lexical(ntpath.join(ROOT, '_scratch', LABEL))
assert lexical(os.environ['LOCALAPPDATA']) == EXPECTED_DATA
assert lexical(os.environ['APPDATA']) == EXPECTED_DATA
assert lexical(os.environ['UOINK_INDEX_PATH']) == ntpath.join(EXPECTED_DATA, 'unused-index.db')

def reject(event, path=None):
    row = {'event': event}
    if path is not None: row['path'] = os.fsdecode(path)
    EVENTS.append(row)
    raise PermissionError('Focused verification guard denied ' + event)

def check_live(value, event):
    name = lexical(value)
    if name is not None and (name == LIVE_DIRECTORY or name.startswith(LIVE_DIRECTORY + '\\')):
        reject(event, value)

# os.path.realpath is included because Windows can query final-path metadata
# directly without calling the public os.stat wrapper. These checks operate
# on strings first and never resolve/stat the forbidden destination itself.
ORIGINALS = {name: getattr(os, name) for name in ('stat', 'lstat', 'readlink')}
ORIGINAL_REALPATH = os.path.realpath
WRAPPERS = {}
for name, original in ORIGINALS.items():
    def wrapped(path, *args, _name=name, _original=original, **kwargs):
        check_live(path, 'os.' + _name)
        return _original(path, *args, **kwargs)
    WRAPPERS[name] = wrapped
    setattr(os, name, wrapped)

def guarded_realpath(path, *args, **kwargs):
    check_live(path, 'os.path.realpath')
    return ORIGINAL_REALPATH(path, *args, **kwargs)
os.path.realpath = guarded_realpath

def audit(event, args):
    if event in {'open', 'sqlite3.connect', 'os.listdir', 'os.scandir'} and args:
        check_live(args[0], event)
    if event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.chmod', 'os.utime'} and args:
        check_live(args[0], event)
    if event in {'os.rename', 'os.link', 'os.symlink'}:
        for value in args[:2]: check_live(value, event)
    if event.startswith('socket.') or event in {
        'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.spawn',
        'os.startfile', 'os.startfile/2', 'os.add_dll_directory',
    }:
        reject(event)
sys.addaudithook(audit)

def pytest_sessionfinish(session, exitstatus):
    installed = all(getattr(os, name) is wrapper for name, wrapper in WRAPPERS.items()) and os.path.realpath is guarded_realpath
    receipt = {'profile': 'reliability-focused-no-network-or-child-process',
        'pytest_exitstatus': int(exitstatus), 'violations': EVENTS,
        'lexical_wrappers_installed_at_finish': installed,
        'audit_hook_installed': True,
        'valid': installed and not EVENTS,
        'scope': 'Cooperative Python process guard; no model/native/OS-sandbox credit. Existing inert test mocks remain permitted.'}
    Path(DESTINATION).write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')

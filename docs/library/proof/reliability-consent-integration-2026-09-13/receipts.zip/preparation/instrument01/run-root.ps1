param(
    [Parameter(Mandatory=$true)][ValidateSet('worker','checkout')][string]$Target,
    [Parameter(Mandatory=$true)][string]$Admission
)
$ErrorActionPreference = 'Stop'
$taskRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$admissionPath = [System.IO.Path]::GetFullPath($Admission)
$scratchRoot = [System.IO.Directory]::GetParent($taskRoot).FullName
if (-not $admissionPath.StartsWith($scratchRoot + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'Root admission must be a JSON file under the integrator scratch directory.'
}
if ([System.IO.Path]::GetExtension($admissionPath) -ne '.json') { throw 'Expected an admission JSON file.' }
$stamp = [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffffffZ')
$receiptDirectory = Join-Path $taskRoot "outer-receipts/$Target-$stamp"
New-Item -ItemType Directory -Path $receiptDirectory -ErrorAction Stop | Out-Null
$arguments = @('-I','-S','-B',(Join-Path $taskRoot 'launch.py'),'--admission',$admissionPath,'--target',$Target)
[ordered]@{executable='C:\Python314\python.exe'; arguments=$arguments; started_utc=[DateTime]::UtcNow.ToString('o')} |
    ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $receiptDirectory 'command.json') -Encoding utf8
& 'C:\Python314\python.exe' @arguments 1> (Join-Path $receiptDirectory 'stdout.log') 2> (Join-Path $receiptDirectory 'stderr.log')
$rawExit = $LASTEXITCODE
[ordered]@{actual_outer_exit=$rawExit; finished_utc=[DateTime]::UtcNow.ToString('o')} |
    ConvertTo-Json | Set-Content -LiteralPath (Join-Path $receiptDirectory 'result.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $receiptDirectory 'stdout.log')
Get-Content -LiteralPath (Join-Path $receiptDirectory 'stderr.log')
exit $rawExit

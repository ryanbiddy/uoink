"""Cross-platform path + OS-integration helpers for the Uoink helper.

Sprint 19.5 Stage 1: every per-platform branch that used to live inline in
server.py (Windows known-folder API, ``%LOCALAPPDATA%``, ``os.startfile``,
PowerShell toast) is consolidated here so the same code paths run on
Windows, macOS, and (future) Linux without ``sys.platform`` branches at
call sites.

This module is Mac-CAPABLE, not yet Mac-tested. Stage 2 packages the Mac
distribution and runs the actual Mac runtime verification; until then the
darwin / linux branches are best-effort + flagged in their docstrings.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
from pathlib import Path
from typing import Iterable

log = logging.getLogger("uoink.platform")

# When we shell out (open / xdg-open / osascript / explorer / notify-send),
# detach stdio so the child never blocks on a pipe and the parent doesn't
# accumulate zombie file descriptors. SUBPROCESS_KW from server.py
# (creationflags=CREATE_NO_WINDOW on Windows) is layered on by the caller
# where applicable -- we keep this module dependency-free so it can be
# imported before server.py finishes initialising.
_DETACHED_IO = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}


# --------------------------------------------------------------------------
# Identity
# --------------------------------------------------------------------------
def platform_label() -> str:
    """Short, stable identifier for /diagnose and log lines."""
    return {
        "win32": "windows",
        "darwin": "macos",
        "linux": "linux",
    }.get(sys.platform, sys.platform)


def platform_detail() -> str:
    """Human-readable ``<os> <arch>`` for /diagnose -- e.g. ``windows
    AMD64``, ``macos arm64``, ``linux x86_64``. The arch comes from
    ``platform.machine()`` (stdlib) which is the machine the Python
    interpreter is running on, not the build target -- so an x86_64
    Python launched under Rosetta on Apple Silicon returns ``x86_64``,
    which is the right answer for "can this install run native binaries"."""
    import platform as _stdlib_platform
    arch = _stdlib_platform.machine() or "unknown"
    return f"{platform_label()} {arch}"


def keyring_display_name() -> str:
    """Human-readable name of the OS credential store the keyring package
    binds to. Used in /diagnose."""
    if sys.platform == "win32":
        return "Windows Credential Manager"
    if sys.platform == "darwin":
        return "macOS Keychain"
    return "Secret Service"


# --------------------------------------------------------------------------
# Path resolution
# --------------------------------------------------------------------------
def user_data_dir() -> Path:
    """Where Uoink stores index.db, settings.json, server.log, the auth
    token, and the migrated jobs.json / taxonomy.json files.

    Windows: ``%LOCALAPPDATA%\\Uoink`` (falls back to
             ``~\\AppData\\Local\\Uoink`` if LOCALAPPDATA is unset, which
             happens in some headless test setups).
    macOS:   ``~/Library/Application Support/Uoink`` (the standard
             container per Apple's File System Programming Guide).
    Linux:   ``$XDG_DATA_HOME/Uoink``, else ``~/.local/share/Uoink``
             (XDG Base Directory Specification).

    v2.1 rename: the Yoink-era equivalents (``%LOCALAPPDATA%\\Yoink`` etc.)
    are migrated into these locations by migrate_install.py on first run.
    """
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(
            Path.home() / "AppData" / "Local"
        )
        return Path(base) / "Uoink"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Uoink"
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg) if xdg else Path.home() / ".local" / "share"
    return base / "Uoink"


def legacy_user_data_dir() -> Path:
    """The pre-rename (Yoink) user-data directory, used only by the one-time
    install migration. Mirrors user_data_dir() with the old brand folder."""
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or str(
            Path.home() / "AppData" / "Local"
        )
        return Path(base) / "Yoink"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Yoink"
    xdg = os.environ.get("XDG_DATA_HOME")
    base = Path(xdg) if xdg else Path.home() / ".local" / "share"
    return base / "Yoink"


def desktop_dir() -> Path:
    """User's Desktop folder.

    Windows uses the known-folder API (``SHGetKnownFolderPath`` with
    ``FOLDERID_Desktop``) so a Desktop redirected to OneDrive is followed
    correctly -- consumer OneDrive opts Desktop in by default, and naive
    ``%USERPROFILE%\\Desktop`` would land uoinks in a folder the user
    can't see in Explorer.

    macOS / Linux assume the standard ``~/Desktop`` location. Linux users
    with XDG_DESKTOP_DIR set to something non-standard get the standard
    path; revisit if Linux ever becomes a shipped target (Sprint 19.5
    Stage 1 ships Windows + Mac only).
    """
    if sys.platform == "win32":
        return _windows_desktop_dir()
    return Path.home() / "Desktop"


# --------------------------------------------------------------------------
# OS integrations
# --------------------------------------------------------------------------
def open_in_os(path: Path | str) -> None:
    """Open a file or folder in the OS's default handler.

    Windows: ``os.startfile`` (registered per-extension handler).
    macOS:   ``open <path>`` (Finder for folders, default app for files).
    Linux:   ``xdg-open <path>``.

    Raises the underlying OSError on failure -- callers wrap in
    try/except for "best-effort, log-on-failure" semantics, matching the
    pre-Sprint-19.5 behaviour where each call site had its own catch."""
    p = str(path)
    if sys.platform == "win32":
        # os.startfile is Windows-only; the type ignore mirrors the
        # comments that used to live at every call site.
        os.startfile(p)  # type: ignore[attr-defined]
        return
    cmd = "open" if sys.platform == "darwin" else "xdg-open"
    subprocess.Popen([cmd, p], **_DETACHED_IO)


def reveal_in_file_manager(path: Path | str) -> None:
    """Open the OS file manager focused on ``path``.

    Windows: ``explorer /select,<path>`` (selects the item in its parent).
    macOS:   ``open -R <path>`` (reveals in Finder).
    Linux:   ``xdg-open <parent>`` -- there's no portable "select this
             specific file" affordance across Linux file managers, so we
             degrade to opening the containing folder.
    """
    p = Path(path)
    if sys.platform == "win32":
        subprocess.Popen(
            ["explorer", f"/select,{p}"], **_DETACHED_IO,
        )
        return
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(p)], **_DETACHED_IO)
        return
    subprocess.Popen(["xdg-open", str(p.parent)], **_DETACHED_IO)


def show_toast(title: str, body: str, icon_path: str | None = None) -> None:
    """Best-effort transient notification when the helper finishes booting.

    Windows: PowerShell + ``System.Windows.Forms.NotifyIcon`` balloon
             (Win10/Win11; suppressed gracefully by Focus Assist).
    macOS:   ``osascript -e 'display notification ...'``.
    Linux:   ``notify-send`` (libnotify) -- silently skipped if missing.

    ``icon_path`` (Windows only) brands the balloon with the bundled
    uoink.ico; falls back to the generic OS information icon when None or
    the file is missing. macOS/Linux notification icons are owned by the OS
    notification centre, so the argument is ignored there.

    Fire-and-forget. Any failure is debug-logged and swallowed -- a
    missing tray icon should never block startup."""
    try:
        if sys.platform == "win32":
            _windows_toast(title, body, icon_path)
        elif sys.platform == "darwin":
            _macos_toast(title, body)
        else:
            _linux_toast(title, body)
    except Exception as e:
        log.debug("toast (%s) failed: %s", platform_label(), e)


def is_foreground_fullscreen(
    *,
    platform_name: str | None = None,
    bounds_probe=None,
) -> bool:
    """Return whether a real foreground window covers its monitor.

    This is deliberately a courtesy signal, not an ownership or security
    boundary. On Windows it catches exclusive-fullscreen games and borderless
    fullscreen windows. Other platforms return False until their window APIs
    have an equally cheap, bounded probe.

    ``bounds_probe`` exists so tests never need to create or focus a window.
    It returns ``(window_rect, monitor_rect, class_name)`` where each rect is
    ``(left, top, right, bottom)``.
    """
    selected_platform = sys.platform if platform_name is None else platform_name
    if selected_platform != "win32":
        return False
    probe = bounds_probe or _windows_foreground_bounds
    try:
        observed = probe()
        if observed is None:
            return False
        window_rect, monitor_rect, class_name = observed
        if class_name in {"Progman", "WorkerW", "Shell_TrayWnd"}:
            return False
        tolerance = 2
        return bool(
            window_rect[0] <= monitor_rect[0] + tolerance
            and window_rect[1] <= monitor_rect[1] + tolerance
            and window_rect[2] >= monitor_rect[2] - tolerance
            and window_rect[3] >= monitor_rect[3] - tolerance
        )
    except (OSError, TypeError, ValueError):
        return False


# --------------------------------------------------------------------------
# Windows-only internals
# --------------------------------------------------------------------------
def _windows_foreground_bounds():
    """Return foreground/monitor bounds without changing window state."""
    import ctypes
    from ctypes import wintypes

    class _RECT(ctypes.Structure):
        _fields_ = [
            ("left", ctypes.c_long),
            ("top", ctypes.c_long),
            ("right", ctypes.c_long),
            ("bottom", ctypes.c_long),
        ]

    class _MONITORINFO(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD),
            ("rcMonitor", _RECT),
            ("rcWork", _RECT),
            ("dwFlags", wintypes.DWORD),
        ]

    user32 = ctypes.windll.user32
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(_RECT)]
    user32.GetWindowRect.restype = wintypes.BOOL
    user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
    user32.MonitorFromWindow.restype = ctypes.c_void_p
    user32.GetMonitorInfoW.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(_MONITORINFO),
    ]
    user32.GetMonitorInfoW.restype = wintypes.BOOL
    user32.GetClassNameW.argtypes = [
        wintypes.HWND,
        wintypes.LPWSTR,
        ctypes.c_int,
    ]
    user32.GetClassNameW.restype = ctypes.c_int
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return None
    window = _RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(window)):
        return None
    monitor = user32.MonitorFromWindow(hwnd, 2)  # MONITOR_DEFAULTTONEAREST
    if not monitor:
        return None
    info = _MONITORINFO()
    info.cbSize = ctypes.sizeof(_MONITORINFO)
    if not user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
        return None
    class_buffer = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, class_buffer, len(class_buffer))

    def values(rect):
        return (rect.left, rect.top, rect.right, rect.bottom)

    return values(window), values(info.rcMonitor), class_buffer.value


def _windows_desktop_dir() -> Path:
    """Windows-specific Desktop resolution via the known-folder API. See
    desktop_dir() for the rationale."""
    fallback = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"
    if sys.platform != "win32":
        # Defensive: this is only invoked from desktop_dir() under the
        # win32 branch, but a future caller might import the symbol
        # directly. Falling back to ~/Desktop is harmless on non-Windows.
        return fallback
    try:
        import ctypes
        from ctypes import wintypes

        class _GUID(ctypes.Structure):
            _fields_ = [
                ("Data1", ctypes.c_uint32),
                ("Data2", ctypes.c_uint16),
                ("Data3", ctypes.c_uint16),
                ("Data4", ctypes.c_ubyte * 8),
            ]

        # FOLDERID_Desktop = {B4BFCC3A-DB2C-424C-B029-7FE99A87C641}
        FOLDERID_Desktop = _GUID(
            0xB4BFCC3A, 0xDB2C, 0x424C,
            (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41),
        )
        SHGetKnownFolderPath = ctypes.windll.shell32.SHGetKnownFolderPath
        SHGetKnownFolderPath.argtypes = [
            ctypes.POINTER(_GUID),
            wintypes.DWORD,
            wintypes.HANDLE,
            ctypes.POINTER(ctypes.c_wchar_p),
        ]
        SHGetKnownFolderPath.restype = ctypes.c_long  # HRESULT

        out = ctypes.c_wchar_p()
        hr = SHGetKnownFolderPath(
            ctypes.byref(FOLDERID_Desktop), 0, None, ctypes.byref(out)
        )
        if hr == 0 and out.value:
            try:
                return Path(out.value)
            finally:
                ctypes.windll.ole32.CoTaskMemFree(out)
    except Exception:
        # Module loads before logging is configured and pythonw.exe has no
        # stderr, so we silently fall back. Users with redirected Desktops
        # will see uoinks under %USERPROFILE%\\Desktop -- not optimal, but
        # workable as a degraded mode.
        pass
    return fallback


def _windows_toast(title: str, body: str, icon_path: str | None = None) -> None:
    # Single-quote escape for PowerShell single-quoted strings.
    t = title.replace("'", "''")
    b = body.replace("'", "''")
    # v2.1: brand the balloon with the bundled uoink.ico when it's available,
    # so the notification carries the rust U rather than the generic blue
    # OS information icon. Fall back to SystemIcons::Information if the icon
    # is missing or can't be loaded (e.g. a corrupt file) -- a failed icon
    # load must never suppress the notification itself.
    if icon_path and os.path.isfile(icon_path):
        ip = icon_path.replace("'", "''")
        icon_line = (
            "try { $n.Icon = New-Object System.Drawing.Icon('" + ip + "') } "
            "catch { $n.Icon = [System.Drawing.SystemIcons]::Information };"
        )
    else:
        icon_line = "$n.Icon = [System.Drawing.SystemIcons]::Information;"
    ps = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "Add-Type -AssemblyName System.Drawing;"
        "$n = New-Object System.Windows.Forms.NotifyIcon;"
        + icon_line +
        "$n.BalloonTipIcon = 'Info';"
        f"$n.BalloonTipTitle = '{t}';"
        f"$n.BalloonTipText = '{b}';"
        "$n.Visible = $true;"
        "$n.ShowBalloonTip(5000);"
        # Keep the tray icon alive long enough for Windows to render the
        # balloon (the timeout arg is advisory; Windows uses a fixed ~5s).
        "Start-Sleep -Seconds 6;"
        "$n.Dispose()"
    )
    # CREATE_NO_WINDOW prevents a console flash; not portable so we set it
    # locally rather than importing server.py's SUBPROCESS_KW (avoids a
    # circular import at module-load time).
    creationflags = 0x08000000  # CREATE_NO_WINDOW
    subprocess.Popen(
        ["powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps],
        creationflags=creationflags,
        **_DETACHED_IO,
    )


# --------------------------------------------------------------------------
# macOS-only internals (Stage 2 will runtime-test these)
# --------------------------------------------------------------------------
def _macos_toast(title: str, body: str) -> None:
    # AppleScript string literals use double-quotes; escape backslashes
    # and double-quotes inside the user-supplied strings to keep the
    # script grammar intact.
    t = title.replace("\\", "\\\\").replace('"', '\\"')
    b = body.replace("\\", "\\\\").replace('"', '\\"')
    script = f'display notification "{b}" with title "{t}"'
    subprocess.Popen(["osascript", "-e", script], **_DETACHED_IO)


# --------------------------------------------------------------------------
# Linux-only internals (future)
# --------------------------------------------------------------------------
def _linux_toast(title: str, body: str) -> None:
    try:
        subprocess.Popen(["notify-send", title, body], **_DETACHED_IO)
    except FileNotFoundError:
        # libnotify isn't installed -- this is fine, the helper still
        # boots, the user just doesn't see a desktop notification.
        log.debug("notify-send not available; toast skipped")

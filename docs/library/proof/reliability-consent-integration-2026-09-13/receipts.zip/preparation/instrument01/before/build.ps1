# Uoink installer build orchestrator.
#
# One-command build:  .\build.ps1
#
# Steps:
#   1. Download Python embeddable, ffmpeg, and get-pip into build\cache\
#      (skipped if already cached).
#   2. Stage the install layout under installer\staging\:
#        python\   embeddable Python with site-packages enabled and
#                  yt-dlp installed via pip
#        bin\      ffmpeg.exe (and ffprobe.exe if present)
#        server.py, migrate_install.py, channels.py, workspaces.py, claims.py,
#        scripts.py, corpus_contract.py, corpus_provider.py,
#        corpus_intelligence.py, memory_layer.py,
#        podcasts.py, mobile_playlists.py,
#        whisper_runner.py, source_manifest.py, openapi_bridge.py,
#        reddit_extractor.py, uoink_mcp.py, uoink_mcp_tools.py, yoink_mcp.py
#        (shim), yt_extract.py, topics.json, skills\,
#        assets\dashboard\, stop-server.{bat,ps1}, uoink.ico
#   3. Run ISCC.exe against installer\uoink.iss to produce
#      build\Uoink-Setup-<version>.exe
#
# See docs\build-installer.md for the architecture rationale and
# instructions on updating Python / yt-dlp / ffmpeg versions.

[CmdletBinding()]
param(
    [switch]$Clean,
    [switch]$StageSourceOnly,
    [string]$SourceStagePath,
    [switch]$ReleaseSigned,
    [string]$SigningCertificateThumbprint,
    [string]$TimestampUrl,
    [string]$SignToolPath
)

$ErrorActionPreference = 'Stop'
# Suppress Invoke-WebRequest's progress UI -- on PS 5.1 it slows large
# downloads to a crawl due to a known performance bug.
$ProgressPreference = 'SilentlyContinue'

# ---- Paths --------------------------------------------------------------
$RepoRoot     = $PSScriptRoot
$InstallerDir = Join-Path $RepoRoot 'installer'
$BuildDir     = Join-Path $RepoRoot 'build'
$CacheDir     = Join-Path $BuildDir 'cache'
$StagingDir   = Join-Path $InstallerDir 'staging'
$TemplatesDir = Join-Path $InstallerDir 'templates'
$IconSrc      = Join-Path $InstallerDir 'uoink.ico'
$InstallerLock = Join-Path $RepoRoot 'requirements-installer-lock.txt'
$verifyInstallerLock = Join-Path $RepoRoot 'scripts\verify_installer_lock.py'
$NltkPathsecWheel = Join-Path $RepoRoot 'vendor\nltk-pathsec\dist\nltk-3.10.3+uoink.pathsec1-py3-none-any.whl'
$NLTK_PATHSEC_SHA256 = '969f623541344ade83ea267130e016d6cb8a223ecaaf28fb3d7a663c7e3c60d8'

$signingArgs = @()
. (Join-Path $RepoRoot 'scripts\installer_signing.ps1')
if ($ReleaseSigned) {
    if ($StageSourceOnly) { throw 'ReleaseSigned requires a complete installer build' }
    Assert-UoinkSigningConfiguration $SigningCertificateThumbprint $TimestampUrl $SignToolPath
    Assert-UoinkSigningCertificate $SigningCertificateThumbprint
    $signingArgs = @('/DReleaseSigning=1', (Get-UoinkInnoSignCommand `
        -PowerShellPath (Get-UoinkSigningPowerShellPath) `
        -CallbackPath (Join-Path $RepoRoot 'scripts\sign_installer.ps1') `
        -CertificateThumbprint $SigningCertificateThumbprint `
        -TimestampUrl $TimestampUrl -SignToolPath $SignToolPath))
} elseif ($SigningCertificateThumbprint -or $TimestampUrl -or $SignToolPath) {
    throw 'Signing parameters require -ReleaseSigned; refusing an accidental unsigned build'
}

# ---- Versions (pinned for v2 ship) --------------------------------------
$VersionSourceFile = Join-Path $RepoRoot 'helper\_version.py'
if (-not (Test-Path $VersionSourceFile)) {
    throw "Missing helper\_version.py version source"
}
$VersionSourceText = Get-Content -Raw $VersionSourceFile
$VersionMatch = [regex]::Match($VersionSourceText, '(?m)^__version__\s*=\s*["''](?<version>\d+\.\d+\.\d+)["'']')
if (-not $VersionMatch.Success) {
    throw "helper\_version.py must define __version__ = 'x.y.z'"
}
$VERSION = $VersionMatch.Groups['version'].Value
Write-Host "Building Uoink version $VERSION" -ForegroundColor Cyan

$VersionFile = Join-Path $RepoRoot 'VERSION'
if (-not (Test-Path $VersionFile)) {
    throw "Missing VERSION file at repo root"
}
$VersionFileValue = (Get-Content -Raw $VersionFile).Trim()
if ($VersionFileValue -ne $VERSION) {
    throw "VERSION file ($VersionFileValue) does not match helper\_version.py ($VERSION). Update helper\_version.py first, then mirror it into VERSION."
}

$ManifestPath = Join-Path $RepoRoot 'extension\manifest.json'
if (-not (Test-Path $ManifestPath)) {
    throw "Missing extension\manifest.json"
}
$ManifestJson = Get-Content -Raw $ManifestPath | ConvertFrom-Json
$ManifestVersion = [string]$ManifestJson.version
if ($ManifestVersion -ne $VERSION) {
    throw "helper\_version.py ($VERSION) does not match extension\manifest.json version ($ManifestVersion). Update helper\_version.py first, then mirror it into the manifest."
}

# Official Windows binary with current 3.13 security fixes. The reviewed
# Python 3.13 graph retains package versions and removes three old backports.
$PYTHON_VERSION = '3.13.15'
$PYTHON_URL     = "https://www.python.org/ftp/python/$PYTHON_VERSION/python-$PYTHON_VERSION-embed-amd64.zip"
$GETPIP_COMMIT  = '5e84c8360eaf92009551b3eec69d734137f31cec'
$GETPIP_URL     = "https://raw.githubusercontent.com/pypa/get-pip/$GETPIP_COMMIT/public/get-pip.py"
# Build tooling affects generated console launchers, RECORD metadata, and
# locally built wheels even though the tools themselves are stripped. Pin it
# just as strictly as the final runtime graph.
$PIP_VERSION        = '26.1.2'
$SETUPTOOLS_VERSION = '83.0.0'
$WHEEL_VERSION      = '0.47.0'
$PACKAGING_VERSION  = '26.2'
# C-02 (license compliance): ffmpeg is now BtbN's win64-LGPL build, not the
# gyan.dev "essentials" GPLv3 build. The essentials build links GPL
# components (x264/x265) and its GPL redistribution obligations (offer of
# source, license text) were never met, which is one leg of the false-MITs
# claim. BtbN publishes an LGPL variant built without the GPL encoders; we
# only need ffmpeg for audio extraction/decoding, so the LGPL build is
# feature-sufficient. Versioned release tag (not "latest") so the hash pin
# below stays meaningful. THIRD-PARTY-NOTICES.md records the LGPL text +
# where to get ffmpeg's source.
$FFMPEG_VERSION = 'n8.1.2'
# BtbN publishes dated release tags; the end-of-month builds are retained
# long-term (daily builds get pruned), so we pin to a monthly snapshot. The
# asset name carries the exact git revision, so this URL is fully pinned --
# it never moves. "win64-lgpl" is the static LGPL variant (no GPL encoders,
# single self-contained ffmpeg.exe -- no DLLs to ship).
$FFMPEG_URL     = "https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2026-08-31-13-27/ffmpeg-n8.1.2-50-g1a748fe2cd-win64-lgpl-8.1.zip"
# TorchCodec 0.7 loads the FFmpeg 7 ABI; the static CLI above has no shared DLLs.
$FFMPEG_SHARED_VERSION = 'n7.1.5'
$FFMPEG_SHARED_URL = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2026-07-31-14-10/ffmpeg-n7.1.5-12-g1fdbca85aa-win64-lgpl-shared-7.1.zip'
$FFMPEG_SHARED_SHA256 = '0f376f96fb38554ccefb1b2ae9c7c6a7b351f0e60a372b38262c320e8392c5d0'
# yt-dlp pip pin -- bump after compatibility-testing a new release.
$YTDLP_VERSION  = '2026.07.04'
# Pillow is used for the multimodal paste-corpus generator (resize +
# JPEG-recompress + base64-encode the embedded screenshots). Pinned to
# a recent stable; bump at release-prep time after testing.
$PILLOW_VERSION = '12.3.0'
# Official Model Context Protocol Python SDK for the stdio MCP server.
# Also pinned in requirements.txt for dev installs and docs.
$MCP_VERSION    = '1.28.1'
# Windows Credential Manager wrapper for Anthropic API key storage.
# Also pinned in requirements.txt for dev installs and docs.
$KEYRING_VERSION = '25.7.0'
# System-tray icon (Tier 1 v2.1.1). Pure-Python; Pillow (already pinned above)
# renders the glyph. Optional at runtime -- server.py degrades if it's missing.
$PYSTRAY_VERSION = '0.19.5'
# Tier 2 GUI: pywebview wraps Codex's helper-served HTML in native windows
# (splash, dashboard). On Windows it uses the Edge WebView2 backend via
# pythonnet/.NET interop -- WebView2 Runtime (Evergreen) ships with Win10/11.
# pythonnet is pinned explicitly so pywebview never silently falls back to the
# legacy MSHTML renderer.
$PYWEBVIEW_VERSION = '5.4'
$PYTHONNET_VERSION = '3.0.5'
# Transcript reliability detection (C-02: was whisper-timestamped, now
# faster-whisper for license compliance -- MIT, no dtw-python/openai-whisper).
# Library ships; the tiny Whisper model downloads lazily to
# %LOCALAPPDATA%\Uoink\models\whisper.
$FASTER_WHISPER_VERSION = '1.2.1'
# v3.1.2 podcast/A1 transcription runtime. This bundles WhisperX and its
# runtime deps into the embeddable Python so podcast transcription works on a
# fresh install; model weights still download only after user consent.
$WHISPERX_VERSION = '3.8.6'

# ---- Hash verification --------------------------------------------------
# Direct-download SHA256s are locked as of v2.0. When bumping Python,
# ffmpeg, or get-pip.py, run build.ps1 once, verify the new artifact source,
# paste the new hash here, and rebuild. Subsequent builds fail with
# "SHA256 mismatch" if anything changes; Confirm-Hash deletes the bad cached
# file so a re-run pulls fresh.
$PYTHON_SHA256 = "d1f04d990aee1253d8569e8e5104e30fa9f5fa830899f14843448872d936a2cf"
$FFMPEG_SHA256 = "f6274bbd9c247f9e90c1bbed066b03ed4a3907cece2fb91be6dd352393936365"
$GETPIP_SHA256 = "a341e1a43e38001c551a1508a73ff23636a11970b61d901d9a1cad2a18f57055"

# ---- Helpers ------------------------------------------------------------
function Write-Step($msg) {
    Write-Host "==> $msg" -ForegroundColor Cyan
}

function Find-Iscc {
    $candidates = @(
        (Join-Path ([Environment]::GetEnvironmentVariable('ProgramFiles(x86)')) 'Inno Setup 6\ISCC.exe'),
        (Join-Path $env:ProgramFiles 'Inno Setup 6\ISCC.exe')
    )
    foreach ($p in $candidates) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    $cmd = Get-Command ISCC.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    throw "ISCC.exe not found. Install Inno Setup 6 from https://jrsoftware.org/isdl.php"
}

function Get-CachedFile($url, $dest) {
    if (Test-Path $dest) {
        Write-Host "    cached: $(Split-Path -Leaf $dest)"
        return
    }
    Write-Host "    downloading $(Split-Path -Leaf $dest) ..."
    $tmp = "$dest.tmp"
    try {
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing
        Move-Item -Force $tmp $dest
    } catch {
        if (Test-Path $tmp) { Remove-Item -Force $tmp }
        throw
    }
}

function Confirm-Hash($path, $expected, $label) {
    $actual = Get-UoinkFileSha256 $path
    if (-not $expected) {
        Write-Warning "    $label has no locked SHA256. Computed: $actual"
        Write-Warning "    Lock it by setting the matching `$..._SHA256 in build.ps1, then rebuild."
        return
    }
    if ($actual -ne $expected.ToLower()) {
        # Remove the bad cache so a re-run downloads fresh, in case the
        # corruption was transient. Don't ship a mismatched artifact.
        Remove-Item -Force -ErrorAction SilentlyContinue $path
        throw "$label SHA256 mismatch.`nExpected: $expected`nActual:   $actual"
    }
    Write-Host "    $label hash OK"
}

function Get-PackageTimestampUtc {
    # SOURCE_DATE_EPOCH is the explicit release-build override. A Git
    # checkout otherwise gets a stable, source-bound timestamp from HEAD; a
    # source archive without Git uses 2000-01-01 rather than wall-clock time.
    $epochText = $env:SOURCE_DATE_EPOCH
    if ([string]::IsNullOrWhiteSpace($epochText)) {
        $git = Get-Command git -ErrorAction SilentlyContinue
        if ($git) {
            $candidate = & $git.Source -C $RepoRoot show -s --format=%ct HEAD 2>$null |
                Select-Object -First 1
            if ($candidate -and "$candidate" -match '^\d+$') {
                $epochText = "$candidate".Trim()
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($epochText)) {
        $epochText = '946684800'
    }

    [long]$epoch = 0
    if (-not [long]::TryParse($epochText, [ref]$epoch) -or $epoch -lt 315532800) {
        throw "SOURCE_DATE_EPOCH must be an integer at or after 1980-01-01 (got '$epochText')"
    }
    try {
        return [DateTimeOffset]::FromUnixTimeSeconds($epoch).UtcDateTime
    } catch {
        throw "SOURCE_DATE_EPOCH is outside the supported range (got '$epochText')"
    }
}

# Source-only staging exercises the production copy list without downloads,
# embedded Python, Inno Setup, task registration or an installed helper.
if ($StageSourceOnly) {
    if ($Clean) { throw 'StageSourceOnly cannot be combined with Clean' }
    if (-not $SourceStagePath) { $SourceStagePath = Join-Path $InstallerDir 'staging-source' }
    $StagingDir = [IO.Path]::GetFullPath($SourceStagePath)
    $allowedRoot = [IO.Path]::GetFullPath($RepoRoot).TrimEnd('\') + '\'
    if (-not $StagingDir.StartsWith($allowedRoot, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'SourceStagePath must be inside this worktree'
    }
    if (Test-Path -LiteralPath $StagingDir) { throw 'SourceStagePath must be a new directory' }
    New-Item -ItemType Directory -Path $StagingDir | Out-Null
}
if (-not $StageSourceOnly) {
# ---- Optional clean -----------------------------------------------------
if ($Clean) {
    Write-Step 'Cleaning build/ and staging/'
    if (Test-Path $StagingDir) { Remove-Item -Recurse -Force $StagingDir }
    if (Test-Path $BuildDir)   { Remove-Item -Recurse -Force $BuildDir }
}

New-Item -ItemType Directory -Force -Path $CacheDir, $BuildDir | Out-Null

# ---- Sanity checks ------------------------------------------------------
# v2.2.0 brand fix: $IconSrc (installer\uoink.ico) is now a BUILD ARTIFACT
# regenerated from assets\logo-mark-color.png by installer\generate_icon.py
# (the regen step runs after pip install, since it uses the bundled Pillow).
# So the preflight here checks the SOURCE PNG instead of the generated .ico;
# the .ico itself is gitignored to prevent the v2.1.x staleness regression
# (it shipped the legacy Yoink-Y all the way through the rebrand).
$logoSrc = Join-Path $RepoRoot 'assets\logo-mark-color.png'
if (-not (Test-Path $logoSrc)) {
    throw "Missing $logoSrc -- can't regenerate installer\uoink.ico"
}
$dashboardIndex = Join-Path $RepoRoot 'assets\dashboard\index.html'
if (-not (Test-Path $dashboardIndex)) {
    throw "Missing assets\dashboard\index.html -- Tier 1 dashboard route would 404"
}
$splashIndex = Join-Path $RepoRoot 'assets\splash\index.html'
if (-not (Test-Path $splashIndex)) {
    throw "Missing assets\splash\index.html -- Tier 2 /splash route would 404"
}
foreach ($f in @(
    'VERSION',
    'helper\_version.py',
    'server.py',
    'index.py',
    '_platform.py',
    'uoink_install_isolation.py',
    'migrate_install.py',
    'channels.py',
    'workspaces.py',
    'claims.py',
    'scripts.py',
    'corpus_contract.py',
    'corpus_provider.py',
    'corpus_intelligence.py',
    'writer_peer.py',
    'engagement_contract.py',
    'media_handoff.py',
    'suite_service.py',
    'memory_layer.py',
    'podcasts.py',
    'mobile_playlists.py',
    'whisper_runner.py',
    'source_manifest.py',
    'openapi_bridge.py',
    # Living Library Phase 2 substrate service (Astra). uoink_mcp_tools.py
    # imports it lazily through one seam; without it every library tool
    # answers service_unavailable, so a build must fail loudly if it is
    # missing rather than ship that state.
    'library_work.py',
    # Living Library Phase 3 standing capture (contract phase3-v1-2026-09-07):
    # subscriptions, consent, detection, start ledger. server.py and
    # uoink_mcp_tools.py import it; migration 0028 ships with the others.
    'source_subscriptions.py',
    'library_analysis.py',
    'library_resources.py',
    'library_prompts.py',
    'library_briefs.py',
    'library_mirror.py',
    'library_mirror_vault_io.py',
    'library_media.py',
    'library_faithfulness.py',
    'reddit_extractor.py',
    'x_extractor.py',
    'x_article_extractor.py',
    'notes.py',
    'images.py',
    'taste_scoring.py',
    'defaults\style_anchors.json',
    'yt_extract.py',
    'topics.json',
    'requirements-installer-lock.txt',
    'scripts\verify_installer_lock.py',
    'installer\verify_install.ps1',
    'uoink_core\storage.py'
)) {
    if (-not (Test-Path (Join-Path $RepoRoot $f))) {
        throw "Missing $f at repo root"
    }
}
# The skill folder is renamed skills\yoink -> skills\uoink by the extension/
# skill agent (Antigravity's chore/rename-extension-to-uoink). That rename is
# a hard prerequisite for a v2.1 build: shipping the legacy skills\yoink\ folder
# would package a Yoink-branded Skill driving the deprecated alias tools. Require
# the renamed skill and fail loudly if it hasn't merged yet -- no legacy fallback.
$skillMd = Join-Path $RepoRoot 'skills\uoink\SKILL.md'
if (-not (Test-Path $skillMd)) {
    throw "Missing skills\uoink\SKILL.md -- Antigravity rename not merged; refusing to build"
}
# Sprint 19.6 / Fix 1: every migrations\NNNN_*.sql ships with the helper --
# missing them silently breaks index.py's _run_migrations at first boot.
$migrationFiles = Get-ChildItem -Path (Join-Path $RepoRoot 'migrations') `
    -Filter '*.sql' -ErrorAction SilentlyContinue
if (-not $migrationFiles -or $migrationFiles.Count -eq 0) {
    throw "Missing migrations\*.sql at repo root"
}

# ---- 1. Download dependencies ------------------------------------------
Write-Step 'Fetching dependencies'
Confirm-Hash $NltkPathsecWheel $NLTK_PATHSEC_SHA256 'NLTK local path-policy wheel'
$pythonZip = Join-Path $CacheDir "python-$PYTHON_VERSION-embed-amd64.zip"
$ffmpegZip = Join-Path $CacheDir "ffmpeg-$FFMPEG_VERSION-win64-lgpl.zip"
$ffmpegSharedZip = Join-Path $CacheDir "ffmpeg-$FFMPEG_SHARED_VERSION-win64-lgpl-shared.zip"
$getPipPy  = Join-Path $CacheDir 'get-pip.py'

Get-CachedFile $PYTHON_URL $pythonZip
Confirm-Hash $pythonZip $PYTHON_SHA256 'Python embeddable'
Get-CachedFile $FFMPEG_URL $ffmpegZip
Confirm-Hash $ffmpegZip $FFMPEG_SHA256 'ffmpeg'
Get-CachedFile $FFMPEG_SHARED_URL $ffmpegSharedZip
Confirm-Hash $ffmpegSharedZip $FFMPEG_SHARED_SHA256 'ffmpeg shared runtime'
Get-CachedFile $GETPIP_URL $getPipPy
Confirm-Hash $getPipPy $GETPIP_SHA256 'get-pip.py'

# ---- 2. Stage -----------------------------------------------------------
Write-Step 'Staging'
if (Test-Path $StagingDir) { Remove-Item -Recurse -Force $StagingDir }
New-Item -ItemType Directory -Force -Path $StagingDir, "$StagingDir\python", "$StagingDir\bin" | Out-Null

# 2a. Extract Python embeddable
Write-Host '    extracting Python embeddable...'
Expand-Archive -Path $pythonZip -DestinationPath "$StagingDir\python" -Force

# 2b. Enable site-packages -- embeddable distributions ship with the
#     `import site` line commented out, which prevents Lib\site-packages
#     from being on sys.path. Uncomment it.
$pthFile = Get-ChildItem -Path "$StagingDir\python" -Filter '*._pth' | Select-Object -First 1
if (-not $pthFile) { throw 'Embeddable archive missing python*._pth' }
$pthContent = Get-Content -Raw $pthFile.FullName
$pthContent = $pthContent -replace '#\s*import\s+site', 'import site'
# Encode as ASCII (no BOM) -- the embeddable launcher reads _pth as bytes
# and a UTF-16 / UTF-8 BOM here will break sys.path setup.
[System.IO.File]::WriteAllText($pthFile.FullName, $pthContent, [System.Text.Encoding]::ASCII)

# 2c. Bootstrap pip into the embeddable
Write-Host '    bootstrapping pip in embeddable Python...'
$embedPython = "$StagingDir\python\python.exe"
& $embedPython $getPipPy --no-warn-script-location --no-compile --no-cache-dir `
    "pip==$PIP_VERSION" "setuptools==$SETUPTOOLS_VERSION" `
    "wheel==$WHEEL_VERSION" "packaging==$PACKAGING_VERSION"
if ($LASTEXITCODE -ne 0) { throw 'pip bootstrap failed' }

# 2d. Install the direct runtime dependencies while constraining the complete
#     transitive graph to the reviewed Windows/CPython 3.13 lock. Artifact
#     hashes remain a separate release control. Pillow drives the multimodal
#     paste-corpus generator
#     (resize / re-encode / base64 screenshots for clipboard embedding).
#     MCP powers uoink_mcp.py for stdio agent integrations. keyring stores
#     the user's Anthropic API key in Windows Credential Manager.
Write-Host "    installing yt-dlp==$YTDLP_VERSION + Pillow==$PILLOW_VERSION + mcp==$MCP_VERSION + keyring==$KEYRING_VERSION + pystray==$PYSTRAY_VERSION + pywebview==$PYWEBVIEW_VERSION + pythonnet==$PYTHONNET_VERSION + faster-whisper==$FASTER_WHISPER_VERSION + whisperx==$WHISPERX_VERSION..."
& $embedPython -m pip install --no-warn-script-location --no-compile --no-cache-dir `
    --no-build-isolation `
    --constraint $InstallerLock `
    $NltkPathsecWheel `
    "yt-dlp==$YTDLP_VERSION" "Pillow==$PILLOW_VERSION" "mcp==$MCP_VERSION" "keyring==$KEYRING_VERSION" "pystray==$PYSTRAY_VERSION" "pywebview==$PYWEBVIEW_VERSION" "pythonnet==$PYTHONNET_VERSION" "faster-whisper==$FASTER_WHISPER_VERSION" "whisperx==$WHISPERX_VERSION"
if ($LASTEXITCODE -ne 0) { throw 'pip install (yt-dlp + Pillow + MCP + keyring + pystray + faster-whisper + whisperx) failed' }

# C-02: regenerate THIRD-PARTY-NOTICES.md from the bundle we just built, so
# the shipped notices match the shipped dependency tree exactly. pip-licenses
# reads the embeddable Python's installed metadata. Best-effort: a missing
# pip-licenses (offline dev build) warns but doesn't fail the build; the
# committed file is the fallback.
Write-Step 'Generating THIRD-PARTY-NOTICES.md'
& $embedPython -m pip install --no-warn-script-location --no-compile --no-cache-dir `
    --no-build-isolation `
    --constraint $InstallerLock "pip-licenses==5.0.0" 2>$null
if ($LASTEXITCODE -eq 0) {
    $noticesPath = Join-Path $RepoRoot 'THIRD-PARTY-NOTICES.md'
    # Stamp the notices from the same source-bound epoch used to normalize
    # installer input mtimes, so regenerating from unchanged source produces an
    # identical file instead of dirtying the tree on every build.
    $priorSourceDateEpoch = $env:SOURCE_DATE_EPOCH
    $env:SOURCE_DATE_EPOCH = [string][DateTimeOffset]::new(
        (Get-PackageTimestampUtc), [TimeSpan]::Zero).ToUnixTimeSeconds()
    & $embedPython (Join-Path $RepoRoot 'scripts\gen_third_party_notices.py') $noticesPath
    $env:SOURCE_DATE_EPOCH = $priorSourceDateEpoch
    if ($LASTEXITCODE -ne 0) { Write-Warning 'THIRD-PARTY-NOTICES generation failed; committed file kept.' }
    # pip-licenses is a build-time tool, not a runtime dep -- strip it back out.
    # Remove the tool and its tool-only dependencies. tomli is not required by
    # the runtime graph on Python 3.13; wcwidth arrives only through prettytable.
    & $embedPython -m pip uninstall -y pip-licenses prettytable tomli wcwidth 2>$null
} else {
    Write-Warning 'pip-licenses unavailable; THIRD-PARTY-NOTICES.md not regenerated.'
}

# 2d-bis. Regenerate installer\uoink.ico from assets\logo-mark-color.png. Uses
# the embeddable Pillow (just installed). Runs BEFORE the staging copy of
# uoink.ico and before ISCC reads SetupIconFile, so both consumers pick up the
# fresh .ico. Single source of truth -> no more rebrand staleness.
Write-Step 'Generating uoink.ico'
& $embedPython (Join-Path $InstallerDir 'generate_icon.py')
if ($LASTEXITCODE -ne 0) { throw 'uoink.ico generation failed' }

# 2e. Trim build-only tools. Torch and CTranslate2 require setuptools at runtime.
# Keep its package, metadata, distutils shim and startup .pth together.
Write-Host '    trimming embeddable...'
$stripGlobs = @(
    "$StagingDir\python\Lib\site-packages\pip*",
    "$StagingDir\python\Lib\site-packages\wheel*",
    "$StagingDir\python\Lib\site-packages\__pycache__"
)
foreach ($g in $stripGlobs) {
    Get-Item -ErrorAction SilentlyContinue $g | ForEach-Object {
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $_.FullName
    }
}
# Strip any stray .pyc caches generated by pip's bootstrap.
Get-ChildItem -Path "$StagingDir\python" -Filter '__pycache__' -Recurse -Directory -ErrorAction SilentlyContinue |
    ForEach-Object { Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $_.FullName }

# Console entry points are not part of Uoink's runtime surface and their
# launchers embed the temporary staging path. Remove them, then remove their
# now-dead RECORD rows so two clean worktrees have the same metadata bytes.
$pythonScripts = Join-Path "$StagingDir\python" 'Scripts'
if (Test-Path $pythonScripts) {
    Remove-Item -Recurse -Force $pythonScripts
}
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
Get-ChildItem -Path "$StagingDir\python\Lib\site-packages" -Filter 'RECORD' -Recurse -File |
    ForEach-Object {
        $recordLines = [System.IO.File]::ReadAllLines($_.FullName)
        $keptLines = @($recordLines | Where-Object {
            $_ -notmatch '^(?:\.\./)+Scripts/'
        })
        [System.IO.File]::WriteAllText(
            $_.FullName,
            (($keptLines -join "`n") + "`n"),
            $utf8NoBom
        )
    }

# The constraints make resolution deterministic; this exact-set check also
# fails if a dependency disappears, appears, or changes version.
Write-Host '    verifying final dependency inventory...'
& $embedPython $verifyInstallerLock $InstallerLock
if ($LASTEXITCODE -ne 0) { throw 'installer dependency lock verification failed' }

# 2f. ffmpeg -- pull just ffmpeg.exe (and ffprobe.exe if present)
Write-Host '    extracting ffmpeg...'
$ffmpegTmp = Join-Path $BuildDir '_ffmpeg_tmp'
if (Test-Path $ffmpegTmp) { Remove-Item -Recurse -Force $ffmpegTmp }
Expand-Archive -Path $ffmpegZip -DestinationPath $ffmpegTmp -Force
$ffmpegExe = Get-ChildItem -Path $ffmpegTmp -Recurse -Filter 'ffmpeg.exe' | Select-Object -First 1
if (-not $ffmpegExe) { throw 'ffmpeg.exe not found inside the BtbN LGPL archive' }
Copy-Item $ffmpegExe.FullName "$StagingDir\bin\ffmpeg.exe" -Force
$ffprobeExe = Get-ChildItem -Path $ffmpegTmp -Recurse -Filter 'ffprobe.exe' | Select-Object -First 1
if ($ffprobeExe) {
    Copy-Item $ffprobeExe.FullName "$StagingDir\bin\ffprobe.exe" -Force
}
Remove-Item -Recurse -Force $ffmpegTmp

# Read only the seven pinned shared-runtime members; do not extract arbitrary
# paths or replace the separately pinned CLI executables. Inno recurses bin/.
$sharedBin = Join-Path $StagingDir 'bin\torchcodec'
New-Item -ItemType Directory -Path $sharedBin | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sharedArchive = [IO.Compression.ZipFile]::OpenRead($ffmpegSharedZip)
try {
    $sharedPrefix = 'ffmpeg-n7.1.5-12-g1fdbca85aa-win64-lgpl-shared-7.1/bin/'
    $sharedNames = @('avcodec-61.dll','avdevice-61.dll','avfilter-10.dll',
        'avformat-61.dll','avutil-59.dll','swresample-5.dll','swscale-8.dll')
    foreach ($sharedName in $sharedNames) {
        $members = @($sharedArchive.Entries | Where-Object { $_.FullName -ceq ($sharedPrefix + $sharedName) })
        if ($members.Count -ne 1) { throw "Expected one shared decoder member: $sharedName" }
        [IO.Compression.ZipFileExtensions]::ExtractToFile($members[0], (Join-Path $sharedBin $sharedName), $false)
    }
} finally {
    $sharedArchive.Dispose()
}

# 2g. Server source + helpers + icon
Write-Host '    copying server source + templates...'
}

Copy-Item (Join-Path $RepoRoot 'server.py')      $StagingDir -Force
# System-tray module (Tier 1 v2.1.1). Imported by server.py at boot on
# installed builds; optional at runtime (degrades if pystray is unavailable).
Copy-Item (Join-Path $RepoRoot 'uoink_tray.py')  $StagingDir -Force
# Tier 2 GUI: splash + dashboard pywebview windows. Imported as subprocess
# entrypoints (not at server import time), but must ship or the tray's
# left-click + the first-run splash crash silently.
Copy-Item (Join-Path $RepoRoot 'uoink_splash.py')    $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'uoink_dashboard.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'index.py')       $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'clips.py')       $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'provenance.py')  $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_cards.py') $StagingDir -Force
# Living Library Phase 2: the work-queue service behind the six library
# registry tools (leases, submissions, previews, apply/undo, pins, recovery).
# Installed imports must work without a checkout (gate P2-0).
Copy-Item (Join-Path $RepoRoot 'library_work.py')  $StagingDir -Force
# Living Library Phase 3: standing capture service (consent, detection, start ledger).
Copy-Item (Join-Path $RepoRoot 'source_subscriptions.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_analysis.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_resources.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_prompts.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_briefs.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_mirror.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_mirror_vault_io.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_media.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'library_faithfulness.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'usage_meter.py')   $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'uoink.cmd')      $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'uoink')          $StagingDir -Force
New-Item -ItemType Directory -Force -Path (Join-Path $StagingDir 'scripts') | Out-Null
Copy-Item (Join-Path $RepoRoot 'scripts\install-watchdog.ps1') (Join-Path $StagingDir 'scripts') -Force
Copy-Item (Join-Path $RepoRoot 'scripts\recall_hook.py') (Join-Path $StagingDir 'scripts') -Force
# Cross-platform path/OS helpers (added Sprint 19.5). server.py and
# migrate_install.py `import _platform` at module top -- omitting it ships a
# helper that crashes with ModuleNotFoundError before binding the port.
Copy-Item (Join-Path $RepoRoot '_platform.py')   $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'uoink_install_isolation.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'migrate_install.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'channels.py')    $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'workspaces.py')  $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'claims.py')      $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'scripts.py')     $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'voice_dna.py')   $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'writing_studio.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'corpus_contract.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'corpus_provider.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'corpus_intelligence.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'writer_peer.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'engagement_contract.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'media_handoff.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'suite_service.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'page_extractor.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'source_manifest.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'openapi_bridge.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'reddit_extractor.py') $StagingDir -Force
# U-15 X text/thread capture. server.py imports x_extractor at module top,
# so it must ship or the helper crashes with ModuleNotFoundError before
# binding the port (cf. reddit_extractor.py). Added v3.2.6.
Copy-Item (Join-Path $RepoRoot 'x_extractor.py') $StagingDir -Force
# V-2c X Article capture. server.py imports x_article_extractor at module top.
Copy-Item (Join-Path $RepoRoot 'x_article_extractor.py') $StagingDir -Force
# Context-layer item 1: quick notes capture. server.py imports notes at module
# top, so it must ship or the helper crashes on launch (cf. x_extractor.py).
Copy-Item (Join-Path $RepoRoot 'notes.py') $StagingDir -Force
# Context-layer item 3: image / meme capture. server.py imports images at
# module top, so it must ship or the helper crashes on launch (cf. notes.py).
Copy-Item (Join-Path $RepoRoot 'images.py') $StagingDir -Force
# V-3 taste-aware auto-uoink. server.py imports taste_scoring at module top,
# so it must ship or the helper crashes with ModuleNotFoundError. Added v3.3.0.
Copy-Item (Join-Path $RepoRoot 'taste_scoring.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'memory_layer.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'podcasts.py')    $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'mobile_playlists.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'whisper_runner.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'uoink_mcp.py')   $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'uoink_mcp_tools.py') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'uoink_reliability.py') $StagingDir -Force
# Back-compat shim (removed in v3): keeps yoink_mcp.py launchable.
Copy-Item (Join-Path $RepoRoot 'yoink_mcp.py')   $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'requirements.txt') $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'yt_extract.py')  $StagingDir -Force
Copy-Item (Join-Path $RepoRoot 'topics.json')    $StagingDir -Force
Set-Content -Path (Join-Path $StagingDir 'VERSION') -Value $VERSION -Encoding ASCII
Copy-Item (Join-Path $RepoRoot 'helper') (Join-Path $StagingDir 'helper') -Recurse -Force
Copy-Item (Join-Path $InstallerDir 'verify_install.ps1') $StagingDir -Force
Copy-Item (Join-Path $InstallerDir 'upgrade_prep.ps1') $StagingDir -Force
Copy-Item (Join-Path $TemplatesDir 'stop-server.bat') $StagingDir -Force
Copy-Item (Join-Path $TemplatesDir 'stop-server.ps1') $StagingDir -Force
if (-not $StageSourceOnly -or (Test-Path -LiteralPath $IconSrc)) {
    Copy-Item $IconSrc (Join-Path $StagingDir 'uoink.ico') -Force
}
# Sprint 21: the uoink_core/ package holds modules split out of server.py.
# server.py imports it at module top, so it must ship or the helper crashes
# with ModuleNotFoundError before binding the port (cf. _platform.py).
Copy-Item (Join-Path $RepoRoot 'uoink_core') (Join-Path $StagingDir 'uoink_core') -Recurse -Force
Copy-Item (Join-Path $RepoRoot 'skills') (Join-Path $StagingDir 'skills') -Recurse -Force
# v3.2 Writing Studio: ship the canonical Voice DNA doc so the helper can
# load VOICE_DNA_PROMPT at boot. voice_dna.py looks in $HERE/voice_dna/
# first, falls back to $HERE/. Sync source is uoink-handoff/VOICE-DNA.md.
Copy-Item (Join-Path $RepoRoot 'voice_dna') (Join-Path $StagingDir 'voice_dna') -Recurse -Force
Copy-Item (Join-Path $RepoRoot 'assets\dashboard') (Join-Path $StagingDir 'assets\dashboard') -Recurse -Force
# Tier 2 GUI: splash HTML (served at /splash and wrapped by uoink_splash.py)
# and the brand tokens stylesheet used by both pages.
Copy-Item (Join-Path $RepoRoot 'assets\splash') (Join-Path $StagingDir 'assets\splash') -Recurse -Force
Copy-Item (Join-Path $RepoRoot 'assets\brand')  (Join-Path $StagingDir 'assets\brand')  -Recurse -Force
# v3.1.3: ship the unpacked Chrome extension beside the helper so the
# first-run hint can point Chrome's "Load unpacked" flow at a real folder.
Copy-Item (Join-Path $RepoRoot 'extension') (Join-Path $StagingDir 'extension') -Recurse -Force
# v2.2.0: canonical rust-U mark used by the tray glyph loader AND by
# installer\generate_icon.py. Shipping it makes the tray's PNG source-of-truth
# pattern work post-install (uoink_tray loads {app}\assets\logo-mark-color.png).
Copy-Item (Join-Path $RepoRoot 'assets\logo-mark-color.png') (Join-Path $StagingDir 'assets\logo-mark-color.png') -Force
# Sprint 19.6 / Fix 1: migrations\*.sql is required at runtime by
# index._run_migrations; if it's missing the helper crashes at first boot
# with "no such table: schema_version". Pre-Sprint-19.6 installers shipped
# without it -- C1 launch blocker.
Copy-Item (Join-Path $RepoRoot 'migrations') (Join-Path $StagingDir 'migrations') -Recurse -Force
# v3.2.3: curated default style anchors, seeded into style_anchors on first run
# by server._seed_default_style_anchors. Must ship or the seed silently no-ops
# (helper still boots, but users get an empty anchor library -- the friction
# this release exists to remove).
Copy-Item (Join-Path $RepoRoot 'defaults') (Join-Path $StagingDir 'defaults') -Recurse -Force

if ($StageSourceOnly) {
    Write-Host "Source staging complete: $StagingDir"
    return
}

# ---- 2h. Staged smoke (Sprint 19.6 / Fix 1) -----------------------------
# Verifies the staged tree is actually runnable BEFORE ISCC packages it,
# so the works-in-repo-breaks-in-installer drift class is caught here
# rather than at first launch on a user's machine.
Write-Step 'Staged smoke'
Push-Location $StagingDir
try {
    & '.\python\python.exe' -m py_compile `
        server.py index.py clips.py provenance.py library_cards.py usage_meter.py migrate_install.py uoink_install_isolation.py channels.py workspaces.py claims.py scripts.py voice_dna.py writing_studio.py corpus_contract.py corpus_provider.py corpus_intelligence.py page_extractor.py writer_peer.py engagement_contract.py media_handoff.py suite_service.py source_manifest.py openapi_bridge.py reddit_extractor.py x_extractor.py x_article_extractor.py notes.py images.py taste_scoring.py memory_layer.py podcasts.py mobile_playlists.py whisper_runner.py uoink_mcp.py uoink_mcp_tools.py uoink_reliability.py yoink_mcp.py yt_extract.py helper\_version.py
    if ($LASTEXITCODE -ne 0) {
        throw 'staged smoke: py_compile of staged Python files failed'
    }
    # Run the smoke from a temp .py FILE, not via `-c`: PowerShell 5.1 mangles
    # embedded double-quotes when handing a multi-line script to a native exe.
    # Two import facts about the embeddable distribution drive the sys.path line:
    # its python._pth lists only python\, the stdlib zip, and site-packages
    # (never the staging root), it ignores PYTHONPATH while a ._pth is present,
    # and it does NOT add the script's own directory either. So the smoke inserts
    # its own dir on sys.path -- exactly what server.py does at runtime
    # (sys.path.insert(0, HERE)) -- or neither index.py nor server.py would import.
    #
    # Checks: (1) index.py imports and migrations\*.sql apply (schema_version is
    # populated from the staged layout), and (2) server.py imports. py_compile
    # above only compiles -- it never runs server.py's top-level imports, so a
    # dropped runtime dependency (e.g. _platform.py) or a missing data file
    # (VERSION) would otherwise sail through and crash the helper at first launch
    # before it binds the port. The file is removed before ISCC packages staging.
    $smokePy = Join-Path $StagingDir '_staged_smoke.py'
    Set-Content -Path $smokePy -Encoding ASCII -Value @'
import json, os, sys, tempfile, pathlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import index
p = pathlib.Path(tempfile.mkdtemp()) / "test.db"
idx = index.Index.open(p)
v = idx._conn.execute("SELECT MAX(version) FROM schema_version").fetchone()[0]
idx.close()
if not v:
    raise SystemExit("smoke: Index.open ran but schema_version is empty; "
                     "migrations/*.sql likely missing from staging")
print("smoke: Index.open OK, schema_version=%s" % v)
import server
expected = (pathlib.Path(__file__).with_name("VERSION")).read_text(encoding="utf-8").strip()
if server.VERSION != expected:
    raise SystemExit("smoke: server.VERSION %s != staged VERSION %s" % (server.VERSION, expected))
print("smoke: import server OK, version=%s" % server.VERSION)
manifest = json.loads((pathlib.Path(__file__).parent / "extension" / "manifest.json").read_text(encoding="utf-8"))
if manifest.get("version") != expected:
    raise SystemExit("smoke: extension manifest %s != staged VERSION %s" % (manifest.get("version"), expected))
print("smoke: extension manifest OK, version=%s" % manifest.get("version"))
import uoink_tray
print("smoke: import uoink_tray OK")
import uoink_splash, uoink_dashboard
print("smoke: import uoink_splash + uoink_dashboard OK")
import whisperx
print("smoke: import whisperx OK")
'@
    try {
        & '.\python\python.exe' $smokePy
        if ($LASTEXITCODE -ne 0) {
            throw 'staged smoke failed: import index/server or Index.open against the staged tree (a required module/file is missing -- e.g. _platform.py, VERSION, or migrations\*.sql)'
        }
    } finally {
        Remove-Item -Force -ErrorAction SilentlyContinue $smokePy
    }
    Write-Host '    Staged smoke OK' -ForegroundColor Green
} finally {
    Pop-Location
}

# ---- 2i. Wizard bitmaps -------------------------------------------------
# Regenerate the branded WizardImage/WizardSmallImage BMPs from source each
# build (no committed binary churn). Uses the staged embeddable Python, which
# has Pillow installed. ISCC reads them from installer\assets\ at compile time
# (they are baked into Setup.exe, not installed into {app}).
Write-Step 'Generating wizard bitmaps'
& $embedPython (Join-Path $InstallerDir 'generate_bitmaps.py')
if ($LASTEXITCODE -ne 0) { throw 'wizard bitmap generation failed' }
$stagedInstallerAssets = Join-Path $StagingDir 'installer-assets'
New-Item -ItemType Directory -Force -Path $stagedInstallerAssets | Out-Null
Get-ChildItem -Path (Join-Path $InstallerDir 'assets') -Filter 'wizard-*.bmp' -File |
    ForEach-Object { Copy-Item $_.FullName $stagedInstallerAssets -Force }

# py_compile, staged imports, and bitmap generation all recreate bytecode after
# the earlier pip cleanup. The staged server import also creates a local token.
# Prune both side effects at the final packaging boundary so no worktree path,
# build timestamp, or build-time credential remains in the staged payload.
Get-ChildItem -Path $StagingDir -Filter '__pycache__' -Recurse -Directory -ErrorAction SilentlyContinue |
    ForEach-Object { Remove-Item -Recurse -Force -ErrorAction SilentlyContinue $_.FullName }
Get-ChildItem -Path $StagingDir -Filter '*.pyc' -Recurse -File -ErrorAction SilentlyContinue |
    ForEach-Object { Remove-Item -Force -ErrorAction SilentlyContinue $_.FullName }
$stagedToken = Join-Path $StagingDir 'token.txt'
if (Test-Path $stagedToken) {
    Remove-Item -Force $stagedToken
}
$remainingBytecode = Get-ChildItem -Path $StagingDir -Filter '*.pyc' -Recurse -File -ErrorAction SilentlyContinue
if ($remainingBytecode) {
    throw "Final staging cleanup left $($remainingBytecode.Count) .pyc files"
}
if (Test-Path $stagedToken) {
    throw 'Final staging cleanup left token.txt'
}

# Inno records source mtimes in setup data. Worktree checkout times made two
# byte-identical staged trees produce different installer wrappers. Normalize
# every compiler input under staging to one source-bound timestamp.
$packageTimestampUtc = Get-PackageTimestampUtc
Get-ChildItem -Path $StagingDir -Recurse -Force |
    ForEach-Object { $_.LastWriteTimeUtc = $packageTimestampUtc }
(Get-Item $StagingDir).LastWriteTimeUtc = $packageTimestampUtc
Write-Host "    normalized package timestamps to $($packageTimestampUtc.ToString('o'))"

# ---- 3. Compile installer ----------------------------------------------
Write-Step 'Compiling installer'
$iscc = Find-Iscc
Write-Host "    using $iscc"
$exe = Join-Path $BuildDir "Uoink-Setup-$VERSION.exe"
$buildAttempt = New-UoinkBuildAttempt $exe
if ($ReleaseSigned) {
    # A fresh cache forces this build's uninstaller through the exact signer;
    # Inno must not reuse a cached signature from another publisher or build.
    $signedUninstallerDir = Join-Path $BuildDir ('signed-uninstallers\' + [Guid]::NewGuid().ToString('N'))
    Assert-UoinkSigningToken $signedUninstallerDir 'SignedUninstallerDir'
    New-Item -ItemType Directory -Path $signedUninstallerDir -ErrorAction Stop | Out-Null
    $signingArgs += "/DReleaseSigningDir=$signedUninstallerDir"
    $signingArgs[1] += (' -ReceiptDirectory $q{0}$q' -f $buildAttempt.callbacks)
}
$issTemplate = Join-Path $InstallerDir 'uoink.iss'
$issGenerated = Join-Path $InstallerDir 'uoink.generated.iss'
$issText = Get-Content -Raw $issTemplate
# NOTE: the trailing \r? is load-bearing. uoink.iss is CRLF on Windows
# checkouts, and .NET's (?m)$ anchors *before* the \n -- with a \r still
# sitting after the closing quote, the bare ".*"$ pattern never matches, the
# AppVersion #define is left at its stale hardcoded value, and ISCC names the
# output Uoink-Setup-<old>.exe (hit during the v2.1.1 build: VERSION/manifest
# were 2.1.1 but the .exe came out 2.1.0). \r? lets $ match on CRLF lines too.
$issText = $issText -replace '(?m)^#define\s+AppVersion\s+".*"\r?$', "#define AppVersion    `"$VERSION`""
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($issGenerated, $issText, $utf8NoBom)
try {
    & $iscc /Q @signingArgs $issGenerated
    if ($LASTEXITCODE -ne 0) { throw 'ISCC compilation failed' }
    if (-not (Test-Path -LiteralPath $exe)) { throw "ISCC reported success but $exe is missing" }
    if ($ReleaseSigned) {
        $signatureDetails = Get-UoinkVerifiedBuildSignatures $buildAttempt $signedUninstallerDir $SigningCertificateThumbprint $SignToolPath
        Set-UoinkBuildAttemptReceipt $buildAttempt 'verified' $signatureDetails
        Write-Host '    installer and uninstaller signatures verified; other release gates still apply'
    } else {
        Set-UoinkBuildAttemptReceipt $buildAttempt 'unsigned' @{sha256=(Get-UoinkFileSha256 $exe)}
        Write-Host '    UNSIGNED REVIEW BUILD: not approved for public release' -ForegroundColor Yellow
    }
} catch {
    Set-UoinkBuildAttemptReceipt $buildAttempt 'failed' @{error=$_.Exception.Message}
    Write-Host "    compile/signing diagnostics: $($buildAttempt.directory)"
    throw
} finally {
    Remove-Item -Force -ErrorAction SilentlyContinue $issGenerated
}

$sizeMb = (Get-Item $exe).Length / 1MB
Write-Host ''
Write-Host ("Built {0} ({1:N1} MB)" -f $exe, $sizeMb) -ForegroundColor Green

# Preparation review — 2026-09-13

Prepared only. No pytest collection, product import, Node process, model or
native product operation has run for this task. The launcher refuses the
unapproved template and cannot infer missing worker paths or test filenames.

The four reference instruments are unchanged copies of the tree09 inputs.
`integrator_verify.py` still creates its original sitecustomize and short
temporary-path fixture, sets isolated application paths and preserves the raw
pytest exit. The existing import blocker denies real heavy modules before
collection while allowing tests to install inert fakes in sys.modules.
The original membership observer and validator retain typed subtest reports,
phase outcomes and raw JUnit counts; they do not change test outcomes.

The only new pytest instrumentation is `reliability_focused_guard.py`. It adds
string-first checks around stat/lstat/readlink/realpath, blocks access within
the ordinary Uoink data directory, and rejects socket/process/OS-launch/DLL
registration events. It wraps metadata operations without changing the results
for ordinary paths. It preserves existing temporary fixtures and source seams.
It is a cooperative Python guard: direct native calls and an adversarial module
that deliberately bypasses it are not accepted by this profile.

The launcher prepares fresh collection/execution labels, verifies the final
source commit and every admitted input before and after each phase, and copies
only three exact pytest plugin files into target scratch. Different existing
plugin bytes cause a stop. Source/test files are read only. Existing named test
bytes, whisper_runner.py, requirements.txt and build.ps1 are pinned to the
preparation baseline. Root must also confirm the final patch stays within the
repair brief and name every added regression file and optional stdlib helper.

Collection defines the complete case set; execution must reproduce it exactly.
Checkout collection must match the worker's separately hash-bound membership.
A failed or abnormal collection stops before execution. Completed failing tests
remain failed. Missing, contradictory or invalid-guard receipts cannot produce
a passing summary. Raw verifier exits are written before validation, and the
PowerShell entry point preserves the actual launcher exit even if validation
throws. It reports unique top-level cases and subtests separately.

Two inputs remain open before root can admit a launch:

- The completed Grok worktree, exact source commit, changed source hashes and
  added regression filenames. None is guessed here.
- Whether the new JavaScript regressions invoke Node. This profile denies every
  real child process. A required Node invocation needs a separate exact reviewed
  script/argument/permission profile before this union runs; it must not be
  omitted or accommodated by a generic subprocess allowance.

No test execution claim follows from syntax parsing or this preparation seal.
The new plugin and launcher still need root source review before use.

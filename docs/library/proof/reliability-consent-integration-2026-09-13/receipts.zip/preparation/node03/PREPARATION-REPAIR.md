The data-only preparer stopped before writing launch.py because its internal
occurrence check expected four plugin-filename strings. The existing launcher
contains three: the required instrument list and the source/destination copy
mapping. Its separate pytest module argument occurs once.

Preserve prepare.py and the actual exit-1 traceback. Continue from launcher
materialization with the count corrected to three. Earlier copied bytes and
the guard/diff already written remain unchanged. This is a preparation-script
assertion correction; no test, Node child or product code was run.

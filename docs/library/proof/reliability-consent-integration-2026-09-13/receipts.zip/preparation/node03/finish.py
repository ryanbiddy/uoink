"""Read/copy/hash/parse text only; no test, Node or product execution."""
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / 'reliability-focused-node02'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def save(name, value):
    path=OUT/name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2)+'\n')
def put(name, text):
    path=OUT/name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
def copy(name, source):
    path=OUT/name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(source.read_bytes())
def patch(name, before, after):
    put('diffs/'+name+'.patch', ''.join(difflib.unified_diff(before.splitlines(keepends=True),
        after.splitlines(keepends=True), fromfile='node02/'+name, tofile='node03/'+name)))

before_launch=(PRIOR/'launch.py').read_text(encoding='utf-8')
launch=before_launch.replace('reliability_focused_guard.py','reliability_focused_guard03.py').replace(
    '_scratch.reliability_focused_guard\'', '_scratch.reliability_focused_guard03\'')
assert launch.count('reliability_focused_guard03.py')==3
assert launch.count('_scratch.reliability_focused_guard03')==1
put('launch.py',launch)
patch('launch.py',before_launch,launch)

copy('receipt01/collection-focused.json',PRIOR/'runs/worker-rlw01/collection-focused.json')
copy('receipt01/raw-exits.json',PRIOR/'runs/worker-rlw01/raw-exits.json')
copy('static-source/platform.py.txt',Path('C:/Python314/Lib/platform.py'))
pytest_source=OUT.parents[1]/'docs/library/proof/partition-subtest-repair-2026-09-13/worker/before/installed-pytest/junitxml.py'
copy('static-source/retained-junitxml.py.txt',pytest_source)

template=json.loads((PRIOR/'ROOT-ADMISSION.TEMPLATE.json').read_text(encoding='utf-8'))
keys=list(template['instrument_hashes'])
keys=[key.replace('reliability_focused_guard.py','reliability_focused_guard03.py') for key in keys]
template['instrument_hashes']={name:sha((OUT/name).read_bytes()) for name in keys}
template['targets']['worker']['label']='rlw02'
template['targets']['worker']['source_commit']='6774d197646cbaa2a3e95b29d2e5bf2cff5a4d26'
template['targets']['checkout']['label']='rlc02'
template['root_reviewed']=False
template['node_profile_reviewed']=False
template['instrument_repair']='Only zero-argument local hostname query admitted; every other socket event denied; new plugin filename preserves copied node02 guard.'
save('ROOT-ADMISSION.TEMPLATE.json',template)

parsed=[]
for name in ['launch.py','reliability_focused_guard03.py','prepare.py']:
    ast.parse((OUT/name).read_text(encoding='utf-8'),filename=str(OUT/name))
    parsed.append(name)
save('PREPARATION-RESULT.json',{'prior36_verified_unchanged':True,'run01_unchanged':True,
    'python_parsed_only':parsed,'node_or_tests_executed':False,
    'static_caller_chain_only':True,'next_root_action':'Source review then fresh admitted worker baseline.'})
put('.gitattributes','* -text\n')
payloads=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file():
        raw=path.read_bytes()
        payloads.append({'file':path.relative_to(OUT).as_posix(),'bytes':len(raw),'sha256':sha(raw)})
save('SHA256.json',{'created_utc':datetime.now(timezone.utc).isoformat(),
    'payload_count':len(payloads),'scope':'Unexecuted local-hostname guard repair preparation', 'payloads':payloads})
print(json.dumps({'payload_count':len(payloads),'manifest_sha256':sha((OUT/'SHA256.json').read_bytes()),
    'source_hashes':{name:sha((OUT/name).read_bytes()) for name in ['launch.py','reliability_focused_guard03.py']},
    'executed_tests_or_node':False}))

"""Materialize a corrected data-only continuation; retain the failed original."""
from pathlib import Path
out=Path(__file__).resolve().parent
source=(out/'prepare.py').read_text(encoding='utf-8')
prefix=source[:source.index('seal_raw=')]
remainder=source[source.index('before_launch='):]
assert remainder.count("assert launch.count('reliability_focused_guard03.py')==4")==1
remainder=remainder.replace("assert launch.count('reliability_focused_guard03.py')==4",
    "assert launch.count('reliability_focused_guard03.py')==3",1)
with (out/'finish.py').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(prefix+remainder)

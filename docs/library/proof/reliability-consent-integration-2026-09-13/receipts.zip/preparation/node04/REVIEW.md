The proposed repair removes the observed lazy-global startup dependency without
admitting another module through the guard. It is ready for root source review;
it has not been executed.

The captured v24.18.0 eval entry calls prepareMainThreadExecution and then
addBuiltinLibsToObject at lines 26–27. The CommonJS flag chooses evalScript,
but changing only that flag would leave the failing global read in place.
[Node eval entry source](https://raw.githubusercontent.com/nodejs/node/v24.18.0/lib/internal/main/eval_string.js)

Both evalScript (line 82) and evalTypeScript (line 248) read globalThis.module
before running user code. The ordinary eval wrapper assigns globalThis.module
at line 441. The raw captured line 248 matches the recorded child traceback.
[Node execution source](https://raw.githubusercontent.com/nodejs/node/v24.18.0/lib/internal/process/execution.js)

The built-in helper skips properties already owned by the global object at
line 241. Otherwise its lazy getter calls dummyModule.require(name) at line 260,
matching the recorded module refusal. The new preload defines that property
as undefined, writable and configurable before closing imports. This is a source
inference supporting the repair; a fresh guarded run must confirm startup.
[Node helper source](https://raw.githubusercontent.com/nodejs/node/v24.18.0/lib/internal/modules/helpers.js)

All three primary captures are exact raw HTTP-200 text responses, bound by URL,
retrieval time, size and SHA256 in PRIMARY-CAPTURE.json. Browser-rendered source
line numbering differed; this review uses the captured raw files. The version
tag was not independently bound to a Git commit or extracted from the installed
executable. No binary provenance claim is added.

The import facade still admits only node:fs and node:vm. Python guard03, launcher,
HARNESS, source/test files, executable, Node mode and permissions remain unchanged.
Only the new preload and brief hashes need updating in root's fresh admission.
The prior copied plugin is reused only when byte-identical.

The rlw02 caller evidence also corrects the earlier hostname hypothesis. Its
recorded stack is jaraco.context.robust_remover -> platform.system -> uname ->
_node -> gethostname. The earlier JUnit chain was a static possibility, not an
observed caller. That inference is withdrawn; the zero-argument local query
allowance itself is unchanged. The prior seal and all rlw02 outcomes remain
untouched, including the six failures and invalid test guard.

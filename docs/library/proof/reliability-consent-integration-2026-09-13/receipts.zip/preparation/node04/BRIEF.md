Prepare a startup-only Node guard repair. Preserve the node03 33-payload seal
and rlw02 receipts. Root observed valid collection of 53 cases, then 47 passed
and 6 failed tests plus 13 passed subtests. The test guard was invalid: five
Node children each refused the built-in module name before reading stdin or
running the VM. The complete-target alias assertion also failed. Retain those
results as recorded; do not call the run accepted.

Read only three public Node v24.18.0 source text files: internal/main/eval_string.js,
internal/process/execution.js and internal/modules/helpers.js. Capture exact
URLs, retrieval times, byte counts and SHA256 values. No binary, model, package,
dependency or other network input is in scope. These version-tagged files guide
the source diagnosis; they are not an extracted proof of the installed binary.

The proposed repair defines an own globalThis.module property with value
undefined before the preload closes imports. Keep it writable/configurable so
Node's normal eval wrapper can assign its module. Node's built-in global helper
skips existing own properties, avoiding the lazy module getter that caused the
recorded refusal. Do not allow module through the import facade. Do not change
the HARNESS, assertions, input mode, executable, permissions or Python plugin.

The predecessor Python guard03 and launcher can be copied unchanged. Their
environment points at the new preload, whose new hash must be root-admitted;
the existing worker guard03 is reused only if identical. Use a fresh rlw03 label
and separate admission after root reviews the exact source delta. Do not launch
Node, pytest, any guard or product/model code during this preparation.

"""Verify and seal text only; no test or Node execution."""
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path
OUT=Path(__file__).resolve().parent
PRIOR=OUT.parent/'reliability-focused-node03'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
prior=json.loads((PRIOR/'SHA256.json').read_bytes())
for row in prior['payloads']:
    raw=(PRIOR/row['file']).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
for name in ['launch.py','reliability_focused_guard03.py','captured-harness.js.txt','NODE-PROFILE.json']:
    assert (OUT/name).read_bytes()==(PRIOR/name).read_bytes()
source=PRIOR/'runs/worker-rlw02/collection-focused.json'
target=OUT/'run02/collection-focused.json'
with target.open('xb') as stream:stream.write(source.read_bytes())
payloads=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file():
        raw=path.read_bytes()
        payloads.append({'file':path.relative_to(OUT).as_posix(),'bytes':len(raw),'sha256':sha(raw)})
with (OUT/'SHA256.json').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),
        'payload_count':len(payloads),'scope':'Unexecuted Node lazy-module startup guard repair preparation',
        'payloads':payloads},indent=2)+'\n')
print(json.dumps({'payload_count':len(payloads),'manifest_sha256':sha((OUT/'SHA256.json').read_bytes()),
    'prior33_verified_unchanged':True,'node_or_tests_executed':False}))

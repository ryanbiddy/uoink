"""Prepare text-only startup repair and public primary-source capture; no tests."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import urllib.request

OUT=Path(__file__).resolve().parent
PRIOR=OUT.parent/'reliability-focused-node03'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(name,value):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,indent=2)+'\n')
def put(name,text):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
def copy(name,source):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(source.read_bytes())

prior_raw=(PRIOR/'SHA256.json').read_bytes()
assert sha(prior_raw)=='1dfd0be4152016645d75b680e52d8ebb5b53034f0ec02806c5e097fb3070095f'
prior=json.loads(prior_raw)
assert prior['payload_count']==33
for row in prior['payloads']:
    raw=(PRIOR/row['file']).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['file']
copy('PREVIOUS33-SHA256.json',PRIOR/'SHA256.json')
names=['launch.py','reliability_focused_guard03.py','EXPECTED-INPUTS.json','NODE-PROFILE.json',
    'captured-harness.js.txt','run-root.ps1','reference/integrator_verify.py',
    'reference/agw_heavy_import_guard.py','reference/partition_receipt_plugin.py',
    'reference/partition_exit_contract.py','reference/pyvenv.cfg','FINISHED-WORKER-BINDINGS.json']
for name in names:copy(name,PRIOR/name)
copy('before/node_guard.cjs',PRIOR/'node_guard.cjs')
before=(PRIOR/'node_guard.cjs').read_bytes()
needle=b"Module._load = function guardedLoad(name) { return facade(name); };"
assert before.count(needle)==1
addition=b"""// Node's eval startup skips lazy builtin globals when an own property exists.
// Its normal eval wrapper assigns this writable slot after the preload returns.
Object.defineProperty(globalThis, 'module', {
  value: undefined, writable: true, configurable: true, enumerable: false,
});
"""
after=before.replace(needle,addition+needle)
(OUT/'node_guard.cjs').write_bytes(after)
put('node-startup.patch',''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
    after.decode().splitlines(keepends=True),fromfile='node03/node_guard.cjs',tofile='node04/node_guard.cjs')))

capture=[]
for member in ['lib/internal/main/eval_string.js','lib/internal/process/execution.js','lib/internal/modules/helpers.js']:
    url='https://raw.githubusercontent.com/nodejs/node/v24.18.0/'+member
    row={'url':url,'started_utc':datetime.now(timezone.utc).isoformat(),'source_version_tag':'v24.18.0'}
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'uoink-source-review/1'}),timeout=20) as response:
            row.update(status=response.status,final_url=response.url)
            if response.url!=url:raise ValueError('Unexpected source redirect')
            raw=response.read(262145)
            if len(raw)>262144:raise ValueError('Source exceeds text bound')
            raw.decode('utf-8')
        filename='primary/'+member.replace('/','__')+'.txt'
        path=OUT/filename;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(raw)
        row.update(file=filename,bytes=len(raw),sha256=sha(raw),success=True)
    except Exception as error:
        row.update(success=False,error=type(error).__name__+': '+str(error))
    row['finished_utc']=datetime.now(timezone.utc).isoformat()
    capture.append(row)
    save('primary/retrieval-%02d.json'%len(capture),row)
save('PRIMARY-CAPTURE.json',capture)
if not all(row['success'] for row in capture):raise RuntimeError('Primary source missing; preserve retrieval failures')

for name in ['tests-focused.json','raw-exits.json']:
    copy('run02/'+name,PRIOR/'runs/worker-rlw02'/name)
for name in ['guard.json','launch.json']:
    copy('run02/node-001/'+name,PRIOR/'runs/worker-rlw02/tests-node/node-001'/name)
template=json.loads((PRIOR/'ROOT-ADMISSION.TEMPLATE.json').read_text(encoding='utf-8'))
template['instrument_hashes']={name:sha((OUT/name).read_bytes()) for name in template['instrument_hashes']}
template['targets']['worker']['label']='rlw03'
template['targets']['checkout']['label']='rlc03'
template['root_reviewed']=False;template['node_profile_reviewed']=False
template['instrument_repair']='Define own undefined global module slot before import closure; no module allowlist or test change.'
save('ROOT-ADMISSION.TEMPLATE.json',template)
put('.gitattributes','* -text\n')
save('PREPARATION-RESULT.json',{'prior33_verified_unchanged':True,
    'python_guard_and_launcher_unchanged':True,'node_or_tests_executed':False,
    'preload_before_sha256':sha(before),'preload_after_sha256':sha(after),
    'public_primary_text_files':len(capture),'status':'Prepared for root review; not execution-qualified'})
print(json.dumps({'prepared':True,'node_guard_sha256':sha(after),'public_primary_files':len(capture),
    'node_or_tests_executed':False}))

# Focused reliability verification admission

2026-09-13. Astra reviewed Grok0851b440's completed three-file product patch,
all three new regressions, the unchanged named companion suites and the two
added review regressions. The original seven worker files and raw diff are
preserved in reliability-grok-original01. Worker helper/Node results are
reported claims without independent raw test receipts in the worktree. Its
extracted-helper execution exceeded the syntax-only Python worker allowance;
do not substitute that claim for the required independent verification.

Astra read the original focused launcher/lexical guard, unchanged verifier
and heavy-import blocker, and the complete Node derivative/adapter/preload
and explicit launcher diff. Accept one worker baseline collection/execution
under reliability-focused-node02, label rlw01, with exactly the five named
suites and four new files bound in the admission JSON. Preserve every raw
failure. The two review cases are expected to expose product defects; that
expectation is not a measurement. No assertion, deselection or xfail change.

The native verification environment uses isolated temporary application
paths. The Python process blocks real heavy imports and ordinary live-data
metadata/access, network and unreviewed children. The only subprocess
exception is the exact frozen Node UI harness, absolute executable/hash,
dashboard/hash and predefined arguments. Node gets only its preload/dashboard
read permissions and one new receipt write, no child/worker/addon permissions.
The preload admits the exact extracted JavaScript with fake DOM/fetch/confirm,
denies other module/network/process operations and records its state. Root
and preparer caught the missing fake-fetch context key before any execution;
the exact-key guard now includes it. The harness and assertions are unchanged.

These are cooperative instruments around reviewed source, not a claim of an
OS security boundary against malicious code. Keep paths quiescent; validate
source, binary and instrument hashes before/after. No model/audio payload,
native model import, installation or ordinary client operation is admitted.
The Node profile has not yet executed; any startup/permission refusal remains
an instrumentation failure requiring a documented repair and a fresh label.

The original-keyword probe02 independently records two controls passing and
the ordinary-default requirement failing, actual exit1. Probe01 failed before
any case due to an AST field lookup; its repair/observed failure remain.
After the baseline, repair only the two documented source defects, retain
all tests unchanged, and use fresh worker/checkout labels for the full union.

Worker rlw01 stopped after collection: 53 cases collected, pytest/verifier0,
but focused guard invalid due to a denied socket.gethostname event. No test
case or Node child ran; the outer launcher exited1. Static pytest JUnit ->
platform.node -> socket.gethostname explains the local metadata request;
run01 has no observed stack, so do not claim that chain was measured there.
Preserve all original receipts and the node02 preparation seal.

Astra reviewed node03's exact guard and launcher diffs and its repair brief.
Permit only zero-argument socket.gethostname, recording up to12 caller
locations without the returned hostname; every other socket event stays
denied. The new plugin name preserves the worker's earlier copied guard.
Node executable/HARNESS/preload and all test/source bytes remain unchanged.
Admit one fresh rlw02 baseline with this exact derivative. Its data preparer's
earlier occurrence-count assertion failure ran no tests and remains preserved.

Worker rlw02 collected 53 cases under valid guards. Execution recorded 47 passed
and 6 failed plus13 passed subtests, pytest/verifier/outer1. Five UI cases failed
before stdin/VM execution because Node24.18's lazy global module getter attempted
a blocked builtin load. They are instrumentation failures. The complete-target
alias failure is a product result. The observed hostname caller was jaraco.context
robust_remover -> platform.system -> uname -> _node; withdraw the earlier JUnit
caller inference. Preserve all original receipts and seals.

Astra reviewed node04's exact startup diff and the relevant captured versioned
Node primary source. Defining the own undefined writable/configurable module
slot before import closure prevents installation of the lazy builtin getter;
the ordinary eval wrapper can still assign it. This is an inference to verify,
not an executed outcome. The only source delta is that definition; the import
facade, Python guard, launcher, Node flags, HARNESS, product and tests are unchanged.
All35 preparation payload hashes/sizes were independently checked. Admit fresh
rlw03 baseline with preload15b9407c and unchanged guard03; preserve any failure.

Worker rlw03 completed valid collection/execution of all53 cases. Actual result:
51 passed /2 failed, plus13 passed subtests; pytest/verifier/outer1. All36 exact
Node children and both Python guards were valid, inputs unchanged. The two
failures are exactly the documented positive-target alias and cross-model-size
regressions. Root then applied only the two source-line repairs named by the
committed repair brief: retain lexical absolute cache root; pass server size
only when selectedIsSaved. No test or harness bytes changed. Admit fresh rlw04
under the unchanged node04 instruments, with the new exact source hashes.

Worker rlw04 passed all53 cases and13 subtests; pytest/verifier/outer0, all36
Node children valid, guard/membership/hash checks passed. Root captured the raw
binary git diff (bb3d7c2aa0309d9bf71aac17b4bf0caf4a014dd2ec06dcd28871866fe49bc1d4)
and applied it with git apply --3way. Git autocrlf changed working bytes of six
source/test files plus the report. Root verified each difference was CRLF only
and restored exact worker bytes, preserving before/after hashes. No semantic
merge conflict. Admit rlc04 on checkout HEAD01a30247 with exact tested file
hashes and worker04 membership; this is pre-commit checkout verification.

"""Original default-keyword reproduction; selected source function, fake constructor."""
import ast
import hashlib
import json
import os
from pathlib import Path
import sys
from typing import Any

ROOT = Path(r"E:\AI\projects\uoink\checkouts\Yoink-library")
DEST = ROOT / "_scratch/reliability-original-keyword02"
SOURCE = ROOT / "uoink_reliability.py"
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode
assert os.environ["IG_FORBIDDEN_LIVE"] == r"C:\Users\hello\AppData\Local\Uoink\index.db"
raw = SOURCE.read_bytes()
tree = ast.parse(raw)
fn = next(item for item in tree.body if isinstance(item, ast.FunctionDef) and item.name == "_load_model")
assert fn.args.kw_defaults[0].value is False
module = ast.Module(body=[fn], type_ignores=[])
calls = []

def factory(name, **kwargs):
    calls.append({"name": name, **kwargs})
    return object()

events = []
def audit(event, args):
    if event == "open":
        value, mode, flags = args
        allowed = {str(DEST / "original-source.py"), str(DEST / "result.json")}
        if not isinstance(value, (str, bytes, os.PathLike)) or os.path.abspath(os.fsdecode(value)) not in allowed:
            events.append(event)
            raise PermissionError("Unexpected probe file access")
    if event.startswith(("socket.", "subprocess.", "ctypes.", "winreg.")) or event in {"os.system", "os.startfile", "os.spawn"}:
        events.append(event)
        raise PermissionError("Unexpected probe operation")

DEST.mkdir(exist_ok=False)
sys.addaudithook(audit)
namespace = {"Path": Path, "Any": Any, "_import_faster_whisper": lambda: factory,
             "_COMPUTE_TYPE": "int8"}
exec(compile(module, "reviewed-original-load-model", "exec"), namespace)
cases = []
for label, kwargs, expected in (
    ("ordinary_default_must_be_local_only", {}, True),
    ("explicit_local_only_control", {"local_files_only": True}, True),
    ("explicit_acquisition_control", {"local_files_only": False}, False),
):
    namespace["_load_model"]("tiny", None, **kwargs)
    observed = calls[-1]["local_files_only"]
    cases.append({"case": label, "expected": expected, "observed": observed,
                  "passed": observed is expected})
failed = sum(not item["passed"] for item in cases)
result = {"scope": "original default-keyword synthetic reproduction", "cases": cases,
          "passed": len(cases)-failed, "failed": failed,
          "source_sha256": hashlib.sha256(raw).hexdigest(),
          "unexpected_events": events, "model_constructed": False,
          "source_module_imported": False, "native_exit_expected": 1 if failed else 0}
(DEST / "original-source.py").write_bytes(raw)
(DEST / "result.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps(result))
raise SystemExit(1 if failed else 0)

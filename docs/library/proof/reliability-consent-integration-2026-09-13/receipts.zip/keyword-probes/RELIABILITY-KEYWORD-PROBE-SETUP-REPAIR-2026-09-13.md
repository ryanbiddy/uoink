# Fix the AST parameter lookup before the baseline probe

Probe01 exited 1 before creating its result directory or running any cases.
Its preflight read FunctionDef.kw_defaults; Python stores that field under
FunctionDef.args.kw_defaults. The shell's attempted receipt write then failed
because the directory had not been created. Preserve this as a setup failure,
not a model or product-test outcome. No selected function executed.

Copy the original script to probe02, change only that AST field access and
the fresh destination label. Preserve probe01 unchanged. Record the observed
setup failure in a separate receipt and create the outer receipt outside the
child-owned output directory. Then execute probe02 once under the same -I -S
-B profile and forbidden-live binding. No model or product module import.
